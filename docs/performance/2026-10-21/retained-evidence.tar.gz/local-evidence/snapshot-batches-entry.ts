
import {readFileSync,writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {JSBSimSdk} from '@felipegalind0/jsbsim';
import {wasmBinaryUrl,wasmModuleUrl} from '@felipegalind0/jsbsim/wasm';
import {captureSimulation as oldCapture} from './baseline-ground-contact/src/safeFlightState.ts';
import {readFlightState as oldState} from './baseline-ground-contact/src/ecefBridge.ts';
import {captureSimulation as newCapture,releaseSimulationCapture,restoreSimulation} from '../../../ground-contact/src/safeFlightState.ts';
import {readFlightState as newState,releaseFlightStateReads} from '../../../ground-contact/src/ecefBridge.ts';
import {createFixedStepPhysicsLoop as oldLoop} from './baseline-fixedStepLoop.ts';
import {createFixedStepPhysicsLoop as newLoop,FIXED_DT} from '../../src/flight/physics/fixedStepLoop.ts';
import {isDeepStrictEqual} from 'node:util';

const manifest=JSON.parse(readFileSync('public/jsbsim-data/manifest.json','utf8'));
let checksum=0;
const median=samples=>[...samples].sort((a,b)=>a-b)[Math.floor(samples.length/2)];
function compare(before,after,n=2400){
 for(let i=0;i<200;i++){before();after();}
 const samples={before:[],after:[]};
 for(let round=0;round<9;round++)for(const key of round%2?['after','before']:['before','after']){
  const fn=key==='before'?before:after,start=performance.now();
  for(let i=0;i<n;i++)fn();
  samples[key].push((performance.now()-start)/n);
 }
 const beforeMs=median(samples.before),afterMs=median(samples.after);
 return {beforeMs,afterMs,speedup:beforeMs/afterMs,savedMsPerSecond120Hz:(beforeMs-afterMs)*120,samples};
}
const report={scope:'Paired Node native JSBSim/WASM benchmark, hold-down at 5000 ft, 120 Hz; full snapshot records and actual fixedStepLoop including guards, ground clearance, SDK run and interpolation. No renderer/GPU.',runs:[]};
for(const [aircraft,model,enginePath,systemsPath] of [
 ['cessna-172','c172p','engine','systems'],
 ['f-35b','F-35B-jsbsim','aircraft/F-35B-jsbsim/Engines','aircraft/F-35B-jsbsim/Systems'],
]){
 const sdk=await JSBSimSdk.create({moduleUrl:wasmModuleUrl,wasmUrl:wasmBinaryUrl,persistence:{enabled:false},log:{console:false}});
 try{
  for(const path of manifest.aircraft[aircraft])sdk.writeDataFile(path,readFileSync('public/jsbsim-data/'+path,'utf8'));
  sdk.configurePaths({rootDir:'/runtime',aircraftPath:'aircraft',enginePath,systemsPath});
  if(!sdk.loadModel(model))throw Error('load failed');
  sdk.setDt(FIXED_DT);sdk.setHoldDown(true);
  for(const [p,v] of Object.entries({'ic/lat-geod-deg':45,'ic/long-gc-deg':-93,'ic/h-sl-ft':5000,'ic/terrain-elevation-ft':0,'ic/vc-kts':aircraft==='f-35b'?300:110,'fcs/throttle-cmd-norm':0.5,'fcs/mixture-cmd-norm':1}))sdk.setPropertyValue(p,v);
  sdk.runIc();sdk.setPropertyValue('propulsion/set-running',-1);sdk.setPropertyValue('fcs/throttle-cmd-norm',0.5);sdk.runIc();
  for(let i=0;i<2400;i++)sdk.run();
  const before=oldCapture(sdk),after=newCapture(sdk);
  if(!isDeepStrictEqual(before,after))throw Error('Snapshot mismatch: '+JSON.stringify({before,after}));
  if(!isDeepStrictEqual(oldState(sdk),newState(sdk)))throw Error('Flight-state mismatch');
  // Exercise exact restoration of the batched record before timing it.
  sdk.run();restoreSimulation(sdk,after);
  const restored=newCapture(sdk);
  for(const [path,value] of Object.entries(after.controls))if(path.includes('/plant/state/')&&Math.abs(restored.controls[path]-value)>1e-9)throw Error('Plant restore changed '+path);
  const capture=compare(()=>{checksum+=oldCapture(sdk).controls['fcs/throttle-cmd-norm'];},()=>{checksum+=newCapture(sdk).controls['fcs/throttle-cmd-norm'];});
  const flightState=compare(()=>{checksum+=oldState(sdk).altMeters;},()=>{checksum+=newState(sdk).altMeters;});
  const beforeLoop=oldLoop(sdk),afterLoop=newLoop(sdk);
  const step=compare(()=>{checksum+=beforeLoop.update(FIXED_DT,()=>true).altMeters;},()=>{checksum+=afterLoop.update(FIXED_DT,()=>true).altMeters;},600);
  if(beforeLoop.getFault()||afterLoop.getFault())throw Error('Loop fault '+beforeLoop.getFault()+' '+afterLoop.getFault());
  const result={aircraft,initialFields:Object.keys(after.initial).length,controlFields:Object.keys(after.controls).length,equalSnapshots:true,plantRestore:true,capture,flightState,fixedStep:step};
  report.runs.push(result);console.log(JSON.stringify(result));
 }finally{releaseFlightStateReads(sdk);releaseSimulationCapture(sdk);sdk.destroy();}
}
report.checksum=checksum;
writeFileSync('build/perf-20261021/snapshot-batches-ab.json',JSON.stringify(report,null,2));
