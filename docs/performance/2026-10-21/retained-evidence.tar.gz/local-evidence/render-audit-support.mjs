import { Matrix, Quaternion, Vector3,                    } from "file:///Users/felg/gh/0sfs/fly/node_modules/@babylonjs/core/index.js";
                                                             

                                                          
                                          
                    
                     
                     
                       
 
                                          
             
                         
                                 
                               
                                                                           
                                                            
 
                                             
                   
                                            
                     
                                  
                             
                                    
 
                                    
                       
                  
                     
                
 
                                   
             
                         
                       
                    
                  
                     
                      
                    
                                                                             
                        
                      
                          
                        
                                                           
                                                                                   
                          
 
                                           
                   
                                                                               
                                        
                                  
                                             
                             
                                    
 

const add = (a           , b           )            => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const subtract = (a           , b           )            => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const scale = (a           , n        )            => [a[0] * n, a[1] * n, a[2] * n];
const dot = (a           , b           )         => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a           , b           )            => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const mix = (a           , b           , t        )            => add(a, scale(subtract(b, a), t));
const norm = (a           )         => Math.hypot(...a);
const normalize = (a           )            => scale(a, 1 / norm(a));
const vector = (v         )            => [v.x, v.y, v.z];
const ring = (z        , radius        , angle = 0, center            )                          => ({
  center: center ?? [0, 0, z], radialU: [Math.cos(angle), 0, -Math.sin(angle)], radialV: [0, 1, 0], radiusMeters: radius,
});
export { ring as engineGasRing };

export function gasSupportInnerRadius(section                  , fraction        )         {
  const knots = section.innerRadiusKnots;
  if (!knots.length) return 0;
  for (let i = knots.length - 1; i >= 0; i--) {
    if (fraction >= knots[i][0]) {
      if (i === knots.length - 1) return knots[i][1];
      const next = knots[i + 1], t = (fraction - knots[i][0]) / (next[0] - knots[i][0]);
      return knots[i][1] + t * (next[1] - knots[i][1]);
    }
  }
  return knots[0][1];
}

/** Forward map used by independent continuity and volume diagnostics. */
export function engineGasSectionPoint(section                  , fraction        , radialFraction        , angle        )            {
  const radius = section.startRadius + fraction * (section.endRadius - section.startRadius);
  return add(mix(section.startCenter, section.endCenter, fraction), scale(add(scale(mix(section.startU, section.endU, fraction), Math.cos(angle)), scale(section.radialV, Math.sin(angle))), radius * radialFraction));
}

/** Exact inverse of the authored ruled circular bearing lofts. No straight-cylinder substitution. */
export function sampleEngineGasSection(section                  , point           , segmentCount = 16, sealHalfWidth = 0.05) {
  const p = subtract(point, section.startCenter), d = subtract(section.endCenter, section.startCenter), du = subtract(section.endU, section.startU);
  const cross2 = (a           , b           ) => dot(cross(a, b), section.radialV);
  const a = -cross2(d, du), b = cross2(p, du) - cross2(d, section.startU), c = cross2(p, section.startU);
  let roots          ;
  if (Math.abs(a) < 1e-12 * Math.max(1, Math.abs(b))) roots = Math.abs(b) > 1e-14 ? [-c / b] : [];
  else {
    const discriminant = b * b - 4 * a * c;
    if (discriminant < 0) return null;
    const q = -0.5 * (b + (b >= 0 ? 1 : -1) * Math.sqrt(discriminant));
    roots = [q / a, q === 0 ? -b / (2 * a) : c / q];
  }
  for (const value of roots) {
    // Babylon stores pose matrices as Float32; shared exported interfaces can
    // differ by sub-micrometre roundoff despite identical authored geometry.
    const endTolerance = 1e-6 / Math.max(norm(d), 1e-6);
    if (value < -endTolerance || value > 1 + endTolerance) continue;
    const fraction = Math.max(0, Math.min(1, value)), u = mix(section.startU, section.endU, fraction), relative = subtract(p, scale(d, fraction));
    const x = dot(relative, u) / dot(u, u), y = dot(relative, section.radialV), radius = section.startRadius + fraction * (section.endRadius - section.startRadius), r = Math.hypot(x, y);
    if (r > radius + 1e-7 || r < gasSupportInnerRadius(section, fraction) - 1e-7) continue;
    if (section.nozzleSealClip) {
      const half = Math.PI / segmentCount, sealRadius = (radius - sealHalfWidth * Math.sin(half)) / Math.cos(half);
      const step = 2 * half, angle = Math.atan2(y, x) - half, wrapped = angle - step * Math.round(angle / step);
      if (r * Math.cos(wrapped) > sealRadius + 1e-7) continue;
    }
    return { fraction, distanceMeters: section.startDistance + fraction * (section.endDistance - section.startDistance), radialFraction: r / radius, radiusMeters: radius };
  }
  return null;
}

export function sampleEngineGasSupport(support                          , point           ) {
  for (let index = 0; index < support.sections.length; index++) {
    const sample = sampleEngineGasSection(support.sections[index], point, support.nozzleSegmentCount, support.nozzleSealHalfWidthMeters);
    if (sample) return { sectionIndex: index, ...sample };
  }
  return null;
}

/** Circular loft volume minus the centrebody; conservative seal clips only reduce it. */
export function engineGasSectionVolume(section                  )         {
  // Two-point Gauss integrates each linear area-factor × quadratic radius exactly.
  const length = section.endDistance - section.startDistance;
  const knots = section.innerRadiusKnots.length ? section.innerRadiusKnots : [[0, 0], [1, 0]]         ;
  let volume = 0;
  for (let i = 0; i < knots.length - 1; i++) {
    const [begin, innerBegin] = knots[i], [end, innerEnd] = knots[i + 1];
    for (const u of [0.5 - 0.5 / Math.sqrt(3), 0.5 + 0.5 / Math.sqrt(3)]) {
      const t = begin + u * (end - begin), radius = section.startRadius + t * (section.endRadius - section.startRadius), innerRadius = innerBegin + u * (innerEnd - innerBegin);
      volume += Math.PI * (radius * radius - innerRadius * innerRadius) * (section.startAreaFactor + t * (section.endAreaFactor - section.startAreaFactor)) * length * (end - begin) / 2;
    }
  }
  return volume;
}

/** Read live rigid transforms without writing any aircraft node or geometry. */
export function bindEngineGasSupport(root               , definition                            ) {
  if (root.name !== definition.rootNode) throw new Error(`Gas support needs ${definition.rootNode}`);
  const nodes = [root, ...root.getDescendants(false)], resolve = (name        ) => {
    const node = nodes.find(candidate => candidate.name === name)                             ;
    if (!node) throw new Error(`Gas support is missing ${name}`);
    return node;
  };
  const frames = new Map                                                                          ();
  const frameFor = (node               ) => {
    let frame = frames.get(node);
    if (!frame) {
      frame = { node, matrix: Matrix.Identity(), accepted: Matrix.Identity() };
      frames.set(node, frame);
    }
    return frame;
  };
  const ducts = definition.ducts.map(duct => ({ duct, frame: frameFor(resolve(duct.attachmentNode)) }));
  const nozzle = frameFor(resolve(definition.nozzleNode));
  const boundFrames = [...frames.values()];
  const localMatrix = Matrix.Identity(), eulerRotation = Quaternion.Identity();
  let revision = 0, cached                                      ;
  let lastThroatRadius = Number.NaN, lastThroatZ = Number.NaN, lastExitRadius = Number.NaN, lastExitZ = Number.NaN;
  let lastLength = Number.NaN, lastSlope = Number.NaN;
  return {
    root,
    update(aperture                   , exteriorLengthMeters        , spreadingSlope        )                           {
      if (!Number.isFinite(exteriorLengthMeters) || !(exteriorLengthMeters > 0) || !Number.isFinite(spreadingSlope) || !(spreadingSlope >= 0)) throw new Error("Gas support needs finite positive exterior length and nonnegative spreading");
      // Native steps can change this root or an ancestor several times within
      // one render ID. Force freshness for the scale guard before taking the
      // relative-pose cache path; an unchanged support must not hide bad scale.
      const rootWorld = root.computeWorldMatrix(true).m, metresPerUnit = Math.hypot(rootWorld[0], rootWorld[1], rootWorld[2]);
      if (!Number.isFinite(metresPerUnit) || Math.abs(metresPerUnit - 1) > 1e-5) throw new Error("Authored F135 gas support requires metre-scale engine geometry");
      let changed = !cached || aperture.throatRadius !== lastThroatRadius || aperture.throatZ !== lastThroatZ
        || aperture.exitRadius !== lastExitRadius || aperture.exitZ !== lastExitZ
        || exteriorLengthMeters !== lastLength || spreadingSlope !== lastSlope;
      for (const frame of boundFrames) {
        // Compare engine-relative matrices before allocating section geometry.
        // Aircraft motion/rebasing cannot alter this support. Reuse the scratch
        // matrices for the hierarchy walk, including live parent changes.
        Matrix.IdentityToRef(frame.matrix);
        let current = frame.node;
        while (current !== root) {
          const rotation = current.rotationQuaternion ?? Quaternion.FromEulerVectorToRef(current.rotation, eulerRotation);
          Matrix.ComposeToRef(current.scaling, rotation, current.position, localMatrix);
          frame.matrix.multiplyToRef(localMatrix, frame.matrix);
          if (!current.parent) throw new Error("Gas support node is outside its engine root");
          current = current.parent                 ;
        }
        if (!frame.matrix.equals(frame.accepted)) changed = true;
      }
      if (!changed) return cached ;
      const transformRing = (matrix        , value                         ) => {
        return { center: vector(Vector3.TransformCoordinates(Vector3.FromArray(value.center), matrix)),
          u: normalize(vector(Vector3.TransformNormal(Vector3.FromArray(value.radialU), matrix))),
          v: normalize(vector(Vector3.TransformNormal(Vector3.FromArray(value.radialV), matrix))), radius: value.radiusMeters };
      };
      const definitions = [
        ...ducts,
        { frame: nozzle, duct: { id: "convergent", attachmentNode: definition.nozzleNode, start: ring(0, definition.nozzleInletRadiusMeters), end: ring(aperture.throatZ, aperture.throatRadius) } },
        { frame: nozzle, duct: { id: "divergent", attachmentNode: definition.nozzleNode, start: ring(aperture.throatZ, aperture.throatRadius), end: ring(aperture.exitZ, aperture.exitRadius) } },
        { frame: nozzle, duct: { id: "exterior", attachmentNode: definition.nozzleNode, start: ring(aperture.exitZ, aperture.exitRadius), end: ring(aperture.exitZ + exteriorLengthMeters, aperture.exitRadius + spreadingSlope * exteriorLengthMeters) } },
      ];
      const sections                     = []; let distance = 0;
      for (const { frame, duct } of definitions) {
        const start = transformRing(frame.matrix, duct.start), end = transformRing(frame.matrix, duct.end);
        // Physical stations and Jacobians depend only on authored local shape,
        // never float32 pose matrices. Vectoring changes uniforms, not radiometry.
        const d = subtract(duct.end.center, duct.start.center), length = norm(d);
        if (dot(start.v, end.v) < 1 - 1e-6 || length <= 0) throw new Error("Gas support requires shared ring V and positive section length");
        sections.push({ id: duct.id, startCenter: start.center, endCenter: end.center, startU: start.u, endU: end.u, radialV: start.v,
          startRadius: start.radius, endRadius: end.radius, startDistance: distance, endDistance: distance + length,
          startAreaFactor: dot(d, cross(duct.start.radialU, duct.start.radialV)) / length, endAreaFactor: dot(d, cross(duct.end.radialU, duct.end.radialV)) / length,
          innerRadiusKnots: "innerRadiusKnots" in duct ? duct.innerRadiusKnots ?? [] : [], nozzleSealClip: duct.id === "convergent" || duct.id === "divergent" });
        distance += length;
      }
      const exitDistance = sections.at(-1) .startDistance;
      for (const section of sections) { section.startDistance -= exitDistance; section.endDistance -= exitDistance; }
      const knots                                            = [];
      for (const section of sections) {
        const inner = section.innerRadiusKnots.length ? section.innerRadiusKnots : [[0, 0], [1, 0]]         ;
        for (const [t, innerRadiusMeters] of inner) {
          const knot = { distanceMeters: section.startDistance + t * (section.endDistance - section.startDistance), radiusMeters: section.startRadius + t * (section.endRadius - section.startRadius), innerRadiusMeters,
            areaFactor: section.startAreaFactor + t * (section.endAreaFactor - section.startAreaFactor) };
          const prior = knots.at(-1);
          if (!prior || prior.distanceMeters !== knot.distanceMeters || prior.radiusMeters !== knot.radiusMeters
            || prior.innerRadiusMeters !== knot.innerRadiusMeters || prior.areaFactor !== knot.areaFactor) knots.push(knot);
        }
      }
      const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
      for (const section of sections) for (const [center, u, radius] of [[section.startCenter, section.startU, section.startRadius], [section.endCenter, section.endU, section.endRadius]]         ) {
        for (let i = 0; i < 3; i++) { const extent = radius * Math.hypot(u[i], section.radialV[i]); min[i] = Math.min(min[i], center[i] - extent); max[i] = Math.max(max[i], center[i] + extent); }
      }
      for (const frame of boundFrames) frame.accepted.copyFrom(frame.matrix);
      lastThroatRadius = aperture.throatRadius; lastThroatZ = aperture.throatZ;
      lastExitRadius = aperture.exitRadius; lastExitZ = aperture.exitZ;
      lastLength = exteriorLengthMeters; lastSlope = spreadingSlope;
      cached = { revision: ++revision, sections, flowDomain: { axialDistanceRangeMeters: [sections[0].startDistance, sections.at(-1) .endDistance], sections: knots },
        bounds: { min: min                        , max: max                         }, nozzleSegmentCount: definition.nozzleSegmentCount, nozzleSealHalfWidthMeters: definition.nozzleSealHalfWidthMeters };
      return cached;
    },
  };
}
