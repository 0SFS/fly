#!/usr/bin/env node
/** Real flight application, JSBSim/WASM and GLBs; an offline fallback globe, no server. */
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "vite";
import { evaluate, openHeadlessChrome, waitForExpression } from "../../scripts/headless-chrome.mjs";
import { newOutputDirectory } from "../../scripts/outputDirectory.mjs";

const root = "/Users/felg/gh/0sfs/fly";
const variant=process.argv.find(a=>a.startsWith('--variant='))?.split('=')[1]??'after';
const out=path.join(root,'build/perf-20261021/controlled-'+variant);
const dependencyFile=path.join(root,'build/perf-20261021/pinned-earth-sources.json');
let pinned={};try{pinned=JSON.parse(await readFile(dependencyFile,'utf8'));}catch{}
const overrides=variant==='before'?[
 [/\/(?:@0sfs\/)?exhaust\/src\/engineGasOptics\.ts$/, 'gas-optics-before/engineGasOptics.ts'],
 [/\/(?:@0sfs\/)?exhaust\/src\/engineExhaustDepth\.ts$/, 'baseline-engineExhaustDepth.ts'],
 [/\/(?:@0sfs\/)?ground-contact\/src\/ecefBridge\.ts$/, 'baseline-ground-contact/src/ecefBridge.ts'],
 [/\/(?:@0sfs\/)?ground-contact\/src\/safeFlightState\.ts$/, 'baseline-ground-contact/src/safeFlightState.ts'],
 [/\/fly\/src\/flight\/jsbsim\/createJsbsimRuntime\.ts$/, 'baseline-createJsbsimRuntime.ts'],
]:[];
const replacements=await Promise.all(overrides.map(async([pattern,file])=>[pattern,await readFile(path.join(root,'build/perf-20261021',file),'utf8')]));
const fixtureRoot = path.join(out, "fixture"), bundleRoot = path.join(out, "bundle");
await mkdir(fixtureRoot, {recursive:true});
const source = relative => JSON.stringify(path.join(root, relative));
// Select the actual runtime's documented offline mode. Every runtime method,
// scene, renderer and flight consumer remains real. Observe its run/pause gate.
const runtimeWrapper = path.join(fixtureRoot, "offline-runtime.ts");
await writeFile(runtimeWrapper, `
export * from ${source("node_modules/foss-earth/src/runtime/index.ts")};
import {createBabylonRuntime as create} from ${source("node_modules/foss-earth/src/runtime/index.ts")};
export async function createBabylonRuntime(canvas,options){
 const runtime=await create(canvas,{...options,googleApiKey:null,preferGoogleTiles:false,rasterBaseMap:null,getSurfaceHeightMeters:()=>0});
 const run=runtime.setSimRunning.bind(runtime);
 runtime.setSimRunning=value=>{window.__aircraftSwitch.running=value;run(value);};
 return runtime;
}
`);
await writeFile(path.join(fixtureRoot, "entry.ts"), String.raw`
import ${source("src/styles/globe.css")};
import ${source("src/styles/flight.css")};
import {getAppSettings} from 'foss-earth/settings';
const test=window.__aircraftSwitch={ready:false,error:null,running:false};
getAppSettings(); // As in main.tsx, diagnostics precede aircraft registration.
import(${source("src/flight/createFlightSimApp.ts")}).then(({createFlightSimApp})=>createFlightSimApp(document.getElementById('root'),{googleApiKey:null,preferGoogleTiles:false})).then(app=>{
 test.app=app;test.runtime=app.runtime;test.canvas=document.querySelector('canvas.flight-app__canvas');
 test.world=app.runtime.getWorldRoot();test.origin=performance.timeOrigin;test.ready=true;
}).catch(error=>{const explain=e=>(e.stack??String(e))+(e.cause?'\nCaused by: '+explain(e.cause):'')+(e.errors?'\n'+e.errors.map(explain).join('\n'):'');test.error=explain(error);test.ready=true;});
`);
await writeFile(path.join(fixtureRoot, "index.html"), '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aircraft switching integration</title></head><body><div id="root"></div><script type="module" src="/entry.ts"></script></body></html>');
const { default: appConfig } = await import("../../vite.config.ts");
if (!process.argv.includes("--no-build")) await build({
  ...appConfig, configFile: false,
  // The fixture owns startup; production boot-terminal graph assertions name
  // the production entry, rather than this instrumented entry.
  plugins: [
    {name:'pin-independent-earth-dependencies',enforce:'pre',transform(code,id){
      for(const [pattern,source]of replacements)if(pattern.test(id))return source;
      if(id.includes('/foss-earth/')||id.includes('/node_modules/foss-earth/')||id.includes('/node_modules/@foss-earth/')){
        if(pinned[id]!==undefined)return pinned[id];
        pinned[id]=code;
      }
      return null;
    },async closeBundle(){await writeFile(dependencyFile,JSON.stringify(pinned));}},
    ...appConfig.plugins.filter(plugin => !["foss-earth-boot-terminal", "copy-index-to-pages-paths"].includes(plugin?.name)),
    { name: "observe-real-flight-snapshots", enforce: "pre", transform(code, id) {
      if (!id.endsWith("/src/flight/hud/createFlightControlPanel.tsx")) return null;
      return code.replace("let snapshot = initialSnapshot;", "let snapshot = initialSnapshot; window.__aircraftSwitch.snapshot = snapshot;")
        .replace("snapshot = nextSnapshot;", "snapshot = nextSnapshot; window.__aircraftSwitch.snapshot = snapshot;");
    } },
  ],
  root: fixtureRoot, publicDir: false, base: "/", logLevel: "warn",
  resolve: { ...appConfig.resolve, alias: [{ find: /^foss-earth\/runtime$/, replacement: runtimeWrapper }] },
  build: { outDir: bundleRoot, emptyOutDir: false, minify: false },
});

if(process.argv.includes("--build-only")){console.log("Build ready",out);process.exit(0);}
const ORIGIN = "https://0sfs.test";
const mime = { ".html":"text/html", ".js":"text/javascript", ".mjs":"text/javascript", ".wasm":"application/wasm", ".css":"text/css", ".json":"application/json", ".xml":"text/xml", ".png":"image/png", ".jpg":"image/jpeg", ".svg":"image/svg+xml", ".woff2":"font/woff2", ".glb":"model/gltf-binary" };
const report = {scope:"Headless offline aircraft diagnostic, flat zero terrain, WebGL2, 1280x800 DPR1. Not a live Google FPS baseline.",runs:[]};
let chrome;
try {
 chrome = await openHeadlessChrome(path.join(out,"chrome-profile"));
 chrome.onEvent(message=>{
  if(message.method==="Runtime.exceptionThrown") console.log("Browser exception:",message.params.exceptionDetails.exception?.description);
  if(message.method!=="Fetch.requestPaused")return;
  void(async()=>{
   const {requestId,request}=message.params;
   const url=new URL(request.url);
   if(url.origin!==ORIGIN){await chrome.send("Fetch.failRequest",{requestId,errorReason:"BlockedByClient"},message.sessionId);return;}
   const base=/^\/(aircraft|jsbsim-data)\//.test(url.pathname)?path.join(root,"public"):bundleRoot;
   const file=path.resolve(base,"."+(url.pathname==="/"?"/index.html":decodeURIComponent(url.pathname)));
   try{
    if(!file.startsWith(base+path.sep))throw Error("Invalid path");
    const bytes=await readFile(file);
    await chrome.send("Fetch.fulfillRequest",{requestId,responseCode:200,responseHeaders:[{name:"Content-Type",value:mime[path.extname(file)]??"application/octet-stream"}],body:bytes.toString("base64")},message.sessionId);
   }catch{await chrome.send("Fetch.fulfillRequest",{requestId,responseCode:404,body:""},message.sessionId);}
  })().catch(error=>console.log(error.message));
 });
 for(const aircraftId of (process.env.PERF_AIRCRAFT??"cessna-172,f-35b").split(",")){
  const {targetId}=await chrome.send("Target.createTarget",{url:"about:blank"});
  const {sessionId}=await chrome.send("Target.attachToTarget",{targetId,flatten:true});
  const run=expr=>evaluate(chrome,sessionId,expr);
  await chrome.send("Runtime.enable",{},sessionId);
  await chrome.send("Page.enable",{},sessionId);
  await chrome.send("Fetch.enable",{patterns:[{urlPattern:"*"}]},sessionId);
  await chrome.send("Emulation.setDeviceMetricsOverride",{width:1280,height:800,deviceScaleFactor:1,mobile:false},sessionId);
  const values={"renderer.mode":"webgl2","osfs.sound.enabled":false,"osfs.start.resume":false,"osfs.aircraft.id":aircraftId,"osfs.aircraft.generation":aircraftId,"osfs.start.heightAboveGround":1500,"osfs.start.airspeed":aircraftId==="f-35b"?300:110};
  await chrome.send("Page.addScriptToEvaluateOnNewDocument",{source:`if(location.origin==='${ORIGIN}')localStorage.setItem('foss-earth.settings.v1',${JSON.stringify(JSON.stringify({version:1,values}))});`},sessionId);
  await chrome.send("Page.navigate",{url:ORIGIN+"/?renderer=webgl2&flightPerf=1"},sessionId);
  await waitForExpression(chrome,sessionId,"window.__aircraftSwitch?.ready===true",120000);
  if(await run("window.__aircraftSwitch.error"))throw Error(await run("window.__aircraftSwitch.error"));
  await waitForExpression(chrome,sessionId,"window.__aircraftSwitch.snapshot?.modelStatus==='ready' && window.osfsFrameProfiler?.summary().frames>120",120000);
  console.log("Ready",aircraftId,await run("window.osfsJsbsimBuild.aircraftId"));
  await chrome.send("Profiler.enable",{},sessionId);
  await chrome.send("Profiler.setSamplingInterval",{interval:100},sessionId);
  await run("window.osfsFrameProfiler.enabled=false;window.osfsFrameProfiler.enabled=true");
  await chrome.send("Profiler.start",{},sessionId);
  await new Promise(resolve=>setTimeout(resolve,8000));
  const {profile}=await chrome.send("Profiler.stop",{},sessionId);
  await writeFile(path.join(out,aircraftId+".cpuprofile"),JSON.stringify(profile));
  const measured=await run("({id:window.osfsJsbsimBuild.aircraftId,summary:window.osfsFrameProfiler.summary(),snapshot:window.__aircraftSwitch.snapshot,running:window.__aircraftSwitch.running,meshes:window.__aircraftSwitch.runtime.scene.meshes.length,gl:window.__aircraftSwitch.runtime.engine.getGlInfo?.()})");
  report.runs.push(measured);
  const self=new Map();
  const nodes=new Map(profile.nodes.map(n=>[n.id,n]));
  for(let i=0;i<profile.samples.length;i++){const n=nodes.get(profile.samples[i]);const key=n.callFrame.functionName+":"+n.callFrame.lineNumber;self.set(key,(self.get(key)??0)+profile.timeDeltas[i]/1000);}
  console.log(JSON.stringify({id:aircraftId,summary:measured.summary,topSelfMs:[...self].sort((a,b)=>b[1]-a[1]).slice(0,25)},null,2));
  if(process.argv.includes('--dirty')&&aircraftId==='f-35b') {
   await run(`(()=>{
    const scene=window.__aircraftSwitch.runtime.scene;
    const material=scene.materials.find(m=>m.getClassName()==='PBRMaterial');
    let prototype=material;
    while(prototype&&!Object.prototype.hasOwnProperty.call(prototype,'_prepareDefines'))prototype=Object.getPrototypeOf(prototype);
    const original=prototype._prepareDefines;
    window.__dirtyMaterials={};
    prototype._prepareDefines=function(mesh,renderingMesh,defines,...rest){
     const key=this.name;
     const record=window.__dirtyMaterials[key]??={count:0,before:{},after:{},changed:{}};
     record.count++;
     const flags=['_areTexturesDirty','_areLightsDirty','_areMiscDirty','_areAttributesDirty','_areImageProcessingDirty','_arePrePassDirty','_isDirty'];
     for(const flag of flags)if(defines[flag])record.before[flag]=(record.before[flag]??0)+1;
     const state=Object.fromEntries(Object.entries(defines).filter(([k,v])=>!k.startsWith('_')&&(typeof v==='boolean'||typeof v==='number'||typeof v==='string')));
     const result=original.call(this,mesh,renderingMesh,defines,...rest);
     for(const flag of flags)if(defines[flag])record.after[flag]=(record.after[flag]??0)+1;
     for(const [k,v]of Object.entries(state))if(defines[k]!==v)record.changed[k]=(record.changed[k]??0)+1;
     return result;
    };
   })()`);
   await new Promise(resolve=>setTimeout(resolve,2500));
   const dirty=await run('window.__dirtyMaterials');
   await writeFile(path.join(out,'dirty-materials.json'),JSON.stringify(dirty,null,2));
   console.log('Dirty diagnostic saved');
  }
  await run("window.__aircraftSwitch.app.destroy()");
  await chrome.send("Target.closeTarget",{targetId});
 }
}finally{
 await chrome?.close();
 await writeFile(path.join(out,"report.json"),JSON.stringify(report,null,2));
 console.log("Report",path.join(out,"report.json"));
}
