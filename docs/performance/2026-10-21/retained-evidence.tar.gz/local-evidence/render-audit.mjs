import {readFile,writeFile} from 'node:fs/promises';
import {stripTypeScriptTypes} from 'node:module';
import {pathToFileURL} from 'node:url';
import * as B from '../../node_modules/@babylonjs/core/index.js';
import '../../node_modules/@babylonjs/loaders/glTF/index.js';
const root='/Users/felg/gh/0sfs';
const out=`${root}/fly/build/perf-20261021`;
const babylon=pathToFileURL(`${root}/fly/node_modules/@babylonjs/core/index.js`).href;
const modules={};
for(const [name,source] of [['nozzle','engines/src/engineNozzleRig.ts'],['rig','aircraft/src/aircraftAnimation.ts'],['support','exhaust/src/engineGasSupport.ts'],['depth','exhaust/src/engineExhaustDepth.ts'],['geometry','F135/src/generated/f135EngineData.ts']]){
 let text=stripTypeScriptTypes(await readFile(`${root}/${source}`,'utf8'));
 text=text.replaceAll('"@babylonjs/core"',JSON.stringify(babylon))
   .replaceAll('"@babylonjs/core/Rendering/depthRendererSceneComponent"',JSON.stringify(pathToFileURL(`${root}/fly/node_modules/@babylonjs/core/Rendering/depthRendererSceneComponent.js`).href))
   .replaceAll('"@0sfs/engines/engineNozzleRig"','"./render-audit-nozzle.mjs"');
 const file=`${out}/render-audit-${name}.mjs`;
 await writeFile(file,text);modules[name]=await import(pathToFileURL(file).href);
}
const {bindAircraftRig,applyAircraftRig,NEUTRAL_CONTROL_SURFACES}=modules.rig;
const {bindEngineGasSupport,engineGasRing:ring}=modules.support;
const {F135_ENGINE_GEOMETRY:g}=modules.geometry;
const {createEngineExhaustDepth}=modules.depth;
const beta=g.bearingTiltDegrees*Math.PI/180;
const supportDef={rootNode:'F135_Engine',nozzleNode:'F135_Nozzle',nozzleInletRadiusMeters:g.aperture.inletRadius,nozzleSegmentCount:g.aperture.segmentCount,nozzleSealHalfWidthMeters:g.aperture.sealHalfWidth,ducts:[
 {id:'augmentor',attachmentNode:'F135_Engine',start:ring(-.75,g.ductInnerRadius),end:ring(0,g.ductInnerRadius),innerRadiusKnots:[[0,.29],[.32/.75,.26],[.60/.75,.15],[.67/.75,.015],[.67/.75,0],[1,0]]},
 {id:'forward-duct',attachmentNode:'F135_Bearing1',start:ring(0,g.ductInnerRadius),end:ring(g.forwardBearingLength,g.ductInnerRadius,beta)},
 {id:'middle-duct',attachmentNode:'F135_Bearing2',start:ring(0,g.ductInnerRadius),end:ring(0,g.ductInnerRadius,-2*beta,[-Math.sin(beta)*g.middleBearingLength,0,Math.cos(beta)*g.middleBearingLength])},
 {id:'aft-duct',attachmentNode:'F135_Bearing3',start:ring(0,g.ductInnerRadius),end:ring(0,g.ductInnerRadius,beta,[Math.sin(beta)*g.aftBearingLength,0,Math.cos(beta)*g.aftBearingLength])},
]};
const report=[];
for(const aircraftId of ['cessna-172','f-35b']){
 const engine=new B.NullEngine({renderWidth:1280,renderHeight:800,textureSize:512,deterministicLockstep:false,lockstepMaxSteps:4});
 const scene=new B.Scene(engine);scene.useRightHandedSystem=true;
 const camera=new B.FreeCamera('camera',new B.Vector3(0,6,27),scene);camera.setTarget(new B.Vector3(0,2,0));camera.minZ=.1;
 new B.HemisphericLight('light',new B.Vector3(0,1,0),scene);
 const paths=aircraftId==='f-35b'?[g.assets[2].path,g.assets[1].path]:['aircraft/cessna-172/Cessna_172_LOD3.glb'];
 const containers=await Promise.all(paths.map(async p=>B.LoadAssetContainerAsync(new Uint8Array(await readFile(`${root}/fly/public/${p}`)),scene,{pluginExtension:'.glb',pluginOptions:{gltf:{skipMaterials:true}}})));
 const nodes=containers.flatMap(c=>c.transformNodes.concat(c.meshes));containers.forEach(c=>c.addAllToScene());
 const rig=bindAircraftRig(nodes,{scene,aircraftId,propellerBlades:aircraftId==='f-35b'?0:2,engineNozzle:aircraftId==='f-35b'?{bearingNames:['F135_Bearing1','F135_Bearing2','F135_Bearing3'],bearingInclinationRad:beta,apertureMechanism:g.aperture}:undefined});
 const state={...NEUTRAL_CONTROL_SURFACES,nozzlePitchRad:0,nozzleYawRad:0,nozzlePositionNorm:.5,propellerRadPerSec:100};
 const measure=(operation,count)=>{
   for(let i=0;i<200;i++)operation(i);
   const samples=[];
   for(let r=0;r<5;r++){const start=performance.now();for(let i=0;i<count;i++)operation(i);samples.push((performance.now()-start)/count);}
   samples.sort((a,b)=>a-b);return {median:samples[2],min:samples[0],max:samples.at(-1)};
 };
 applyAircraftRig(rig,state,1/60);
 const result={aircraftId,meshes:scene.meshes.length,nodes:scene.transformNodes.length,rigParts:rig.parts.length,rigStovl:rig.stovl.length,gear:rig.gear.length,rigUnchangedMs:measure(()=>applyAircraftRig(rig,state,1/60),10000),renderMs:measure(()=>scene.render(),400)};
 if(rig.engineNozzle){
   const support=bindEngineGasSupport(nodes.find(n=>n.name==='F135_Engine'),supportDef);
   result.supportUnchangedMs=measure(()=>support.update(rig.engineNozzle.apertureGeometry,6,.07),10000);
   result.rigChangedApertureMs=measure(i=>{state.nozzlePositionNorm=.5+.1*Math.sin(i);applyAircraftRig(rig,state,1/60)},10000);
   result.supportChangedMs=measure(i=>{rig.engineNozzle.update(0,0,.5+.1*Math.sin(i));support.update(rig.engineNozzle.apertureGeometry,6,.07)},10000);
   const plume=B.MeshBuilder.CreateBox('plume',{width:2,height:2,depth:6},scene);plume.position.set(0,2.2,6);
   const originalReady=B.DepthRenderer.prototype.isReady;B.DepthRenderer.prototype.isReady=()=>true;
   const depth=createEngineExhaustDepth(scene,plume,()=>{});depth.setActive(true,1);
   result.depthCandidateScanMs=measure(()=>scene.onBeforeRenderObservable.notifyObservers(scene),10000);
   result.depthCandidates=depth.texture.renderList.length;
   result.renderWithDepthMs=measure(()=>scene.render(),400);
   depth.dispose();B.DepthRenderer.prototype.isReady=originalReady;
 }
 report.push(result);scene.dispose();engine.dispose();
}
await writeFile(`${out}/render-audit-report.json`,JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
