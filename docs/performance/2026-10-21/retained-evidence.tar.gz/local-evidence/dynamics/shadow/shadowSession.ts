/**
 * The native work of one attempted fixed step, as the app's applyInputs and
 * fixedStepLoop.ts run it, once the main thread has answered the step's scene
 * queries. Shared by the shadow worker and the main-thread parity reference,
 * so both execute identical code against their own SDK.
 */
import type { JSBSimSdk } from "@felipegalind0/jsbsim";
import { applyFlightControls } from "@0sfs/controls/applyFlightControls";
import { readFlightState } from "@0sfs/ground-contact/ecefBridge";
import { captureSimulation, invalidFlightStateReasons, restoreSimulation } from "@0sfs/ground-contact/safeFlightState";
import { groundContactClearanceMeters } from "@0sfs/ground-contact/groundContactClearance";
import { readControlSurfaceState } from "@0sfs/aircraft/aircraftAnimation";
import { readExternalFuelTanks } from "@0sfs/fuel/externalFuelTanks";
import { readFuelTanks } from "@0sfs/fuel/fuelTanks";
import { readPilotG } from "@0sfs/g-forces/gForce";
import type { AircraftId } from "@0sfs/aircraft/aircraftIds";
import type { FlightState } from "@0sfs/ground-contact/flightState";
import { INSTRUMENT_PATHS, OBS, STATE_FIELDS, SURFACE_FIELDS } from "./protocol";

const MAX_GROUND_PENETRATION_METERS = 0.5;
// The reads the app's arbiter, engine control and assists make between the
// scene queries and applyFlightControls (inventory steps 5–7).
const ASSIST_READS = [
  "gear/unit[0]/WOW", "gear/unit[1]/WOW", "gear/unit[2]/WOW",
  "attitude/phi-rad", "attitude/theta-rad", "attitude/psi-rad", "velocities/p-rad_sec", "velocities/q-rad_sec",
  "velocities/r-rad_sec", "velocities/vc-kts", "velocities/h-dot-fps",
  "propulsion/engine[0]/set-running", "propulsion/engine[0]/thrust-lbs",
  "aero/qbar-psf", "velocities/vt-fps", "accelerations/qdot-rad_sec2", "accelerations/pdot-rad_sec2",
] as const;

export type StepOutcome = { accepted: true; state: FlightState; audio: unknown } | { accepted: false; fault: string };

export function packState(state: FlightState, into: Float64Array, offset = 0): void {
  for (let index = 0; index < STATE_FIELDS.length; index++) into[offset + index] = state[STATE_FIELDS[index]];
}

export function createShadowSession(sdk: JSBSimSdk, aircraftId: AircraftId, audio: { read(): unknown } | null) {
  let observeCount = 0;
  return {
    preStepState: (): FlightState => readFlightState(sdk),

    /** Steps 1–9 of the inventory after the scene replies, then accepted-step audio. */
    step(terrainHeightMeters: number | null, applyArgs: readonly unknown[] | null): StepOutcome {
      if (terrainHeightMeters !== null && Number.isFinite(terrainHeightMeters)) {
        sdk.setPropertyValue("position/terrain-elevation-asl-ft", terrainHeightMeters / 0.3048);
      }
      for (const path of ASSIST_READS) sdk.getPropertyValue(path);
      if (applyArgs) (applyFlightControls as (...args: unknown[]) => void)(sdk, ...applyArgs);

      const before = readFlightState(sdk);
      if (invalidFlightStateReasons(before).length > 0) return { accepted: false, fault: "invalid state before stepping" };
      const terrainMeters = sdk.getPropertyValue("position/terrain-elevation-asl-ft") * 0.3048;
      const penetration = terrainMeters + groundContactClearanceMeters(sdk, before.rollRad, before.pitchRad) - before.altMeters;
      if (penetration > MAX_GROUND_PENETRATION_METERS) return { accepted: false, fault: "deep ground impact" };
      const snapshot = captureSimulation(sdk);
      const success = sdk.run();
      const candidate = readFlightState(sdk);
      const deltaLon = ((candidate.lonDeg - before.lonDeg + 540) % 360) - 180;
      const distance = Math.hypot((candidate.latDeg - before.latDeg) * 111320,
        deltaLon * Math.cos(before.latDeg * Math.PI / 180) * 111320, candidate.altMeters - before.altMeters);
      if (!success || invalidFlightStateReasons(candidate).length > 0 || distance > 100
        || Math.abs(candidate.airspeedKts - before.airspeedKts) > 200) {
        restoreSimulation(sdk, snapshot);
        return { accepted: false, fault: "rejected step" };
      }
      return { accepted: true, state: candidate, audio: audio?.read() ?? null };
    },

    /** The presentation reads the app makes once per rendered frame. */
    observe(state: FlightState, stepId: number, appliedInputSeq: number): Float64Array {
      const out = new Float64Array(OBS.length);
      packState(state, out, OBS.state);
      const surfaces = readControlSurfaceState(sdk, aircraftId) as unknown as Record<string, number | boolean | undefined>;
      SURFACE_FIELDS.forEach((field, index) => {
        const value = surfaces[field];
        out[OBS.surfaces + index] = typeof value === "boolean" ? Number(value) : value ?? NaN;
      });
      const tanks = readExternalFuelTanks(sdk, aircraftId);
      for (let index = 0; index < 4; index++) out[OBS.tanks + index] = index < tanks.length ? Number(tanks[index]!.attached) : NaN;
      out[OBS.pilotG] = readPilotG(sdk);
      INSTRUMENT_PATHS.forEach((path, index) => { out[OBS.instruments + index] = sdk.getPropertyValue(path); });
      // The panel reads all tanks at 10 Hz; at 60 Hz observations that is every sixth.
      out[OBS.fuelTanks] = observeCount++ % 6 === 0 ? readFuelTanks(sdk).reduce((sum, tank) => sum + tank.contentsLbs, 0) : NaN;
      out[OBS.stepId] = stepId;
      out[OBS.appliedInputSeq] = appliedInputSeq;
      return out;
    },
  };
}
