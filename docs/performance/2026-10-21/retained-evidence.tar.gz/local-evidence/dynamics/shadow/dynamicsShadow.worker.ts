/**
 * Experiment only, not shipped: a dedicated worker that owns one JSBSim SDK
 * and runs the app's per-step native work in lockstep with exact scene-query
 * replies from the main thread. It runs beside the app's own simulation
 * ("shadow mode") so the main thread's transport and terrain-service cost can
 * be measured in the real browser frame. It is not an authoritative flight.
 */
import "../../../../src/flight/aircraft/fleet";
import { createJsbsimRuntime, type JsbsimRuntime } from "../../../../src/flight/jsbsim/createJsbsimRuntime";
import { getFdmProfile, type EngineModelId } from "../../../../src/flight/jsbsim/fdmProfiles";
import { restoreSimulation, type SimulationSnapshot } from "@0sfs/ground-contact/safeFlightState";
import { createJsbsimAudioAdapter } from "@0sfs/sound/jsbsimAudioAdapter";
import { getAircraftAudioInstallation, resolveAircraftAudioInstallation } from "@0sfs/sound/aircraftAudioProfiles";
import type { AircraftId } from "@0sfs/aircraft/aircraftIds";
import type { FlightState } from "@0sfs/ground-contact/flightState";
import { PROTOCOL_VERSION, STATE_LENGTH, type MainToWorker, type StepRecord, type TerrainReplyBody, type WorkerStats, type WorkerToMain } from "./protocol";
import { createShadowSession, packState } from "./shadowSession";

// The app compiles against the DOM library, so type the worker scope locally.
const scope = globalThis as unknown as {
  postMessage(message: unknown, transfer: Transferable[]): void;
  onmessage: ((event: MessageEvent<MainToWorker>) => void) | null;
};
const FIXED_DT = 1 / 120;
const MAX_ACCUMULATED_SECONDS = FIXED_DT * 6;

let generation = -1;
let outSeq = 0;
let lastInSeq = -1;
let runtime: JsbsimRuntime | null = null;
let session: ReturnType<typeof createShadowSession> | null = null;
let applyArgs: unknown[] | null = null;
let latestInputSeq = -1;
let accumulator = 0;
let pumping = false;
let paused = false;
let fault: string | null = null;
let stepId = 0;
let requestId = 0;
let previousPreStep: FlightState | null = null;
let pending: { requestId: number; resolve: (reply: TerrainReplyBody | null) => void } | null = null;
let recording = false;
let records: StepRecord[] = [];
let audioBatch: unknown[] = [];
const stats: WorkerStats = { acceptedSteps: 0, busyMs: 0, roundTrips: 0, roundTripMs: 0, maxRoundTripMs: 0, droppedMs: 0 };

type Outgoing = WorkerToMain extends infer M ? M extends unknown ? Omit<M, "v" | "gen" | "seq"> : never : never;
const post = (message: Outgoing, transfer: Transferable[] = []): void => {
  scope.postMessage({ ...message, v: PROTOCOL_VERSION, gen: generation, seq: outSeq++ }, transfer);
};
const packed = (state: FlightState): Float64Array => { const out = new Float64Array(STATE_LENGTH); packState(state, out); return out; };

/** Ask for this exact pre-step state's scene queries; resolves null if cancelled. */
function query(state: FlightState): Promise<TerrainReplyBody | null> {
  const id = ++requestId;
  const current = packed(state);
  const prev = previousPreStep ? packed(previousPreStep) : null;
  post({ type: "query", requestId: id, stepId, state: current, prev }, prev ? [current.buffer, prev.buffer] : [current.buffer]);
  return new Promise(resolve => { pending = { requestId: id, resolve }; });
}

function cancelPending(): void {
  const waiting = pending;
  pending = null;
  waiting?.resolve(null);
}

async function pump(): Promise<void> {
  if (pumping) return;
  pumping = true;
  const startGeneration = generation;
  let last: FlightState | null = null;
  try {
    while (!fault && !paused && session && accumulator >= FIXED_DT) {
      const pre = session.preStepState();
      const asked = performance.now();
      const reply = await query(pre);
      if (!reply || generation !== startGeneration || !session) return;
      const roundTrip = performance.now() - asked;
      stats.roundTrips++; stats.roundTripMs += roundTrip; stats.maxRoundTripMs = Math.max(stats.maxRoundTripMs, roundTrip);
      // A reply names the step it answered; never run a step on another state's reply.
      if (reply.stepId !== stepId) { fault = `terrain reply for step ${reply.stepId} while at ${stepId}`; break; }
      const started = performance.now();
      const terrain = reply.sample?.heightMeters ?? null;
      const outcome = session.step(terrain, applyArgs);
      if (!outcome.accepted) { fault = outcome.fault; stats.busyMs += performance.now() - started; break; }
      previousPreStep = pre;
      last = outcome.state;
      if (outcome.audio) audioBatch.push(outcome.audio);
      if (recording) records.push({ stepId, inputSeq: latestInputSeq, terrainHeightMeters: terrain ?? NaN,
        state: packed(outcome.state), audio: outcome.audio ? JSON.stringify(outcome.audio) : null });
      stepId++;
      stats.acceptedSteps++;
      accumulator -= FIXED_DT;
      stats.busyMs += performance.now() - started;
    }
    if (last && session) {
      // One latest-wins observation per drained batch, with the ordered audio readings.
      const started = performance.now();
      const observation = session.observe(last, stepId, latestInputSeq);
      stats.busyMs += performance.now() - started;
      const batch = audioBatch, recorded = records;
      audioBatch = []; records = [];
      post({ type: "observation", observation, audio: batch, records: recorded, stats: { ...stats } }, [observation.buffer]);
    }
  } catch (error) {
    fault = error instanceof Error ? error.stack ?? error.message : String(error);
  } finally {
    pumping = false;
    if (fault && generation === startGeneration) post({ type: "fault", reason: fault });
  }
}

async function start(message: Extract<MainToWorker, { type: "start" }>): Promise<void> {
  const startedAt = performance.now();
  const aircraftId = message.aircraftId as AircraftId;
  const engineModel = (message.engineModel ?? undefined) as EngineModelId | undefined;
  const profile = getFdmProfile(aircraftId, engineModel);
  const created = await createJsbsimRuntime({ aircraftId, engineModel, dataBaseUrl: message.dataBaseUrl,
    bootstrap: { latDeg: 0, lonDeg: 0, altFt: 5000, headingDeg: 0, airspeedKts: profile.initialAirspeedKts ?? 100 } });
  if (generation !== message.gen) { created.dispose(); return; } // superseded while loading
  runtime = created;
  restoreSimulation(created.sdk, message.snapshot as SimulationSnapshot);
  let audio: { read(): unknown } | null = null;
  const installation = message.audio ? getAircraftAudioInstallation(aircraftId) : null;
  if (installation) {
    const admitted = resolveAircraftAudioInstallation(installation);
    if (admitted.supported) audio = createJsbsimAudioAdapter(created.sdk, { gearHeightMetres: profile.stance.staticMeters, source: admitted.source });
  }
  session = createShadowSession(created.sdk, aircraftId, audio);
  applyArgs = message.applyArgs;
  recording = message.record;
  post({ type: "ready", startupMs: performance.now() - startedAt, state: packed(session.preStepState()) });
}

function dispose(): void {
  cancelPending();
  session = null;
  runtime?.dispose();
  runtime = null;
}

scope.onmessage = (event: MessageEvent<MainToWorker>) => {
  const message = event.data;
  // Version, generation and order are checked before anything can touch native state.
  if (message?.v !== PROTOCOL_VERSION) return;
  if (message.type === "start") {
    dispose();
    generation = message.gen;
    lastInSeq = message.seq;
    outSeq = 0; stepId = 0; requestId = 0; accumulator = 0; fault = null; paused = false;
    previousPreStep = null; latestInputSeq = -1; records = []; audioBatch = [];
    Object.assign(stats, { acceptedSteps: 0, busyMs: 0, roundTrips: 0, roundTripMs: 0, maxRoundTripMs: 0, droppedMs: 0 });
    start(message).catch(error => post({ type: "fault", reason: `startup: ${error instanceof Error ? error.stack ?? error.message : String(error)}` }));
    return;
  }
  if (message.gen !== generation || message.seq <= lastInSeq) return;
  lastInSeq = message.seq;
  switch (message.type) {
    case "tick": {
      if (!session) return;
      if (message.applyArgs) applyArgs = message.applyArgs;
      latestInputSeq = message.inputSeq;
      const dt = Number.isFinite(message.dtS) ? Math.min(Math.max(message.dtS, 0), 0.1) : 0;
      const wanted = accumulator + dt;
      accumulator = Math.min(wanted, MAX_ACCUMULATED_SECONDS);
      stats.droppedMs += (wanted - accumulator) * 1000;
      void pump();
      break;
    }
    case "terrain": {
      if (!pending || pending.requestId !== message.requestId) return; // stale or cancelled
      const waiting = pending;
      pending = null;
      waiting.resolve(message);
      break;
    }
    case "record":
      recording = message.enabled;
      break;
    case "pause":
      paused = message.paused;
      if (paused) { accumulator = 0; cancelPending(); }
      break;
    case "dispose":
      dispose();
      post({ type: "disposed" });
      generation = -1;
      break;
  }
};
