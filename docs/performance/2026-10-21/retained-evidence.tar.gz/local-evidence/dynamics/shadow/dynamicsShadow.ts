/**
 * Main-thread side of the shadow dynamics worker (experiment only): the exact
 * scene-query service, per-frame input tickets and observation handling. Its
 * whole cost is timed under the top-level profiler section "dynamics", so it
 * counts in the measured main-thread frame.
 *
 * Also a transport-parity check: a main-thread reference SDK, created and
 * restored exactly as the worker's, replays the worker's recorded inputs and
 * terrain replies through the same step code; every accepted state, audio
 * reading and observation must be bit-identical.
 */
import { DEG_TO_RAD, geodeticToEcef } from "foss-earth/cameraMath";
import type { SurfaceQuery } from "foss-earth/runtime";
import type { JSBSimSdk } from "@felipegalind0/jsbsim";
import { captureSimulation, restoreSimulation } from "@0sfs/ground-contact/safeFlightState";
import { BODY_COLLISION_PROBES, MAX_BODY_COLLISION_ALTITUDE_METERS, type BodyCollisionProbe } from "@0sfs/ground-contact/collisionGeometry";
import { createJsbsimAudioAdapter } from "@0sfs/sound/jsbsimAudioAdapter";
import { getAircraftAudioInstallation, resolveAircraftAudioInstallation } from "@0sfs/sound/aircraftAudioProfiles";
import type { AircraftId } from "@0sfs/aircraft/aircraftIds";
import { createJsbsimRuntime } from "../../../../src/flight/jsbsim/createJsbsimRuntime";
import { getFdmProfile, type EngineModelId } from "../../../../src/flight/jsbsim/fdmProfiles";
import { OBS, PROTOCOL_VERSION, type MainToWorker, type StepRecord, type TerrainReplyBody, type WorkerStats, type WorkerToMain } from "./protocol";
import { createShadowSession, packState } from "./shadowSession";

interface Hook { sdk: JSBSimSdk; surface: SurfaceQuery; aircraftId: AircraftId; engineModel: string | null; applyArgs: unknown[] | null }
interface Profiler { clock(): number; add(section: string, startedAt: number): void }
interface Vec { x: number; y: number; z: number }

const hook = (): Hook => {
  const value = (globalThis as { __dynHook?: Hook }).__dynHook;
  if (!value) throw new Error("The app has not exposed its simulation hook yet");
  return value;
};
const profiler = (): Profiler | undefined => (globalThis as { osfsFrameProfiler?: Profiler }).osfsFrameProfiler;
const now = () => performance.now();
const stat = (values: number[]) => {
  if (!values.length) return { n: 0, mean: 0, p50: 0, p95: 0, max: 0 };
  const sorted = [...values].sort((a, b) => a - b);
  const at = (rank: number) => sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * rank))]!;
  return { n: sorted.length, mean: sorted.reduce((sum, value) => sum + value, 0) / sorted.length, p50: at(0.5), p95: at(0.95), max: sorted[sorted.length - 1]! };
};

// --------------------------------------------- swept probes (as visibleMeshCollision.ts)
const add = (a: Vec, b: Vec): Vec => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
const scale = (v: Vec, f: number): Vec => ({ x: v.x * f, y: v.y * f, z: v.z * f });
const subtract = (a: Vec, b: Vec): Vec => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
function probePosition(s: Float64Array, probe: BodyCollisionProbe): Vec {
  const lat = s[0]! * DEG_TO_RAD, lon = s[1]! * DEG_TO_RAD, roll = s[3]!, pitch = s[4]!, heading = s[5]!;
  const north = { x: -Math.sin(lat) * Math.cos(lon), y: -Math.sin(lat) * Math.sin(lon), z: Math.cos(lat) };
  const east = { x: -Math.sin(lon), y: Math.cos(lon), z: 0 };
  const upAxis = { x: Math.cos(lat) * Math.cos(lon), y: Math.cos(lat) * Math.sin(lon), z: Math.sin(lat) };
  const levelForward = add(scale(north, Math.cos(heading)), scale(east, Math.sin(heading)));
  const levelRight = add(scale(north, -Math.sin(heading)), scale(east, Math.cos(heading)));
  const forward = add(scale(levelForward, Math.cos(pitch)), scale(upAxis, Math.sin(pitch)));
  const pitchedUp = subtract(scale(upAxis, Math.cos(pitch)), scale(levelForward, Math.sin(pitch)));
  const left = subtract(scale(pitchedUp, Math.sin(roll)), scale(levelRight, Math.cos(roll)));
  const up = add(scale(pitchedUp, Math.cos(roll)), scale(levelRight, Math.sin(roll)));
  const offset = add(scale(left, probe.left), add(scale(up, probe.up), scale(forward, probe.forward)));
  return add(geodeticToEcef(lat, lon, s[2]!), offset);
}

export function createDynamicsShadow() {
  let worker: Worker | null = null;
  let generation = 0;
  let outSeq = 0;
  let lastInSeq = -1;
  let raf = 0;
  let lastFrameAt: number | null = null;
  let inputSeq = 0;
  let ready: { resolve: (value: unknown) => void; reject: (error: Error) => void } | null = null;
  let disposed: (() => void) | null = null;
  let fault: string | null = null;
  let start: { aircraftId: AircraftId; engineModel: string | null; dataBaseUrl: string; snapshot: unknown; audio: boolean; applyArgs: unknown[] | null } | null = null;
  let probes: readonly BodyCollisionProbe[] = BODY_COLLISION_PROBES;
  let lastHit: { lat: number; lon: number; revision: unknown } | null = null;
  // The two latest accepted observations, for render interpolation.
  let latest = new Float64Array(OBS.length), previous = new Float64Array(OBS.length);
  let haveObservation = false;
  const sentAt = new Float64Array(1024);
  let lastAppliedSeq = -1;
  let workerStats: WorkerStats | null = null;
  let recording = false;
  let recorded: StepRecord[] = [];
  const recordedArgs = new Map<number, unknown[] | null>();
  let effectiveArgs: unknown[] | null = null;
  const m = {
    queries: 0, replies: 0, raycasts: 0, anchors: 0, misses: 0, observations: 0, audioReadings: 0, ticks: 0, staleMessages: 0,
    terrainMs: [] as number[], observationMs: [] as number[], tickMs: [] as number[],
    inputToObservedMs: [] as number[], lagFramesAtFrame: [] as number[], queriesPerFrame: [] as number[],
    stepsPerObservation: [] as number[], queriesThisFrame: 0, lastStepId: 0,
  };

  const send = (message: Record<string, unknown>, transfer: Transferable[] = []) => {
    worker?.postMessage({ ...message, v: PROTOCOL_VERSION, gen: generation, seq: outSeq++ } as MainToWorker, transfer);
  };
  const timed = <T>(section: string, list: number[], fn: () => T): T => {
    const p = profiler();
    const t = p?.clock() ?? 0;
    const started = now();
    try { return fn(); } finally {
      list.push(now() - started);
      // Child first, then the top-level section that the frame total counts.
      p?.add(section, t);
      p?.add("dynamics", t);
    }
  };

  function serve(message: Extract<WorkerToMain, { type: "query" }>): void {
    const { surface } = hook();
    const s = message.state;
    const lat = s[0]!, lon = s[1]!, alt = s[2]!;
    const hit = surface.sample(lat, lon);
    let anchorHeightMeters: number | null = null;
    if (hit && lastHit && hit.revision !== lastHit.revision) {
      m.anchors++;
      anchorHeightMeters = surface.sample(lastHit.lat, lastHit.lon)?.heightMeters ?? null;
    }
    if (hit) lastHit = { lat, lon, revision: hit.revision }; else m.misses++;
    let impactFraction: number | null = null, raycasts = 0;
    if (message.prev && hit && alt - hit.heightMeters <= MAX_BODY_COLLISION_ALTITUDE_METERS) {
      for (const probe of probes) {
        const from = probePosition(message.prev, probe);
        const movement = subtract(probePosition(s, probe), from);
        const distance = Math.hypot(movement.x, movement.y, movement.z);
        if (!Number.isFinite(distance) || distance < 0.0001) continue;
        raycasts++;
        const ray = surface.raycast(from, movement, distance);
        if (ray && Number.isFinite(ray.distanceMeters) && ray.distanceMeters >= 0 && ray.distanceMeters <= distance) {
          const fraction = ray.distanceMeters / distance;
          if (impactFraction === null || fraction < impactFraction) impactFraction = fraction;
        }
      }
    }
    m.raycasts += raycasts;
    const quality = hit && (typeof hit.quality === "number" || typeof hit.quality === "string") ? hit.quality : null;
    const reply: TerrainReplyBody = {
      requestId: message.requestId, stepId: message.stepId,
      sample: hit ? { heightMeters: hit.heightMeters, revision: Number(hit.revision), quality } : null,
      anchorHeightMeters, impactFraction, raycasts,
    };
    send({ type: "terrain", ...reply });
    m.replies++;
  }

  function observe(message: Extract<WorkerToMain, { type: "observation" }>): void {
    // Copy the coherent observation into presentation-owned storage.
    const swap = previous; previous = latest; latest = swap;
    latest.set(message.observation);
    haveObservation = true;
    m.observations++;
    m.audioReadings += message.audio.length;
    const stepId = latest[OBS.stepId]!;
    m.stepsPerObservation.push(stepId - m.lastStepId);
    m.lastStepId = stepId;
    workerStats = message.stats;
    const applied = latest[OBS.appliedInputSeq]!;
    // Input-to-applied: the frame ticket's send until its accepted step is observable here.
    for (let seq = lastAppliedSeq + 1; seq <= applied; seq++) if (seq >= 0 && seq > inputSeq - sentAt.length) m.inputToObservedMs.push(now() - sentAt[seq % sentAt.length]!);
    lastAppliedSeq = Math.max(lastAppliedSeq, applied);
    if (recording) recorded.push(...message.records);
  }

  function onMessage(event: MessageEvent<WorkerToMain>): void {
    const message = event.data;
    if (message?.v !== PROTOCOL_VERSION || message.gen !== generation || message.seq <= lastInSeq) { m.staleMessages++; return; }
    lastInSeq = message.seq;
    switch (message.type) {
      case "query": m.queries++; m.queriesThisFrame++; timed("dynamics/terrain", m.terrainMs, () => serve(message)); break;
      case "observation": timed("dynamics/observation", m.observationMs, () => observe(message)); break;
      case "ready": ready?.resolve({ startupMs: message.startupMs }); ready = null; break;
      case "fault": fault = message.reason; ready?.reject(new Error(message.reason)); ready = null; break;
      case "disposed": disposed?.(); disposed = null; break;
    }
  }

  function frame(timestamp: number): void {
    raf = requestAnimationFrame(frame);
    const dtS = lastFrameAt === null ? 0 : (timestamp - lastFrameAt) / 1000;
    lastFrameAt = timestamp;
    timed("dynamics/tick", m.tickMs, () => {
      // How many frame tickets the presented observation is behind.
      if (haveObservation) m.lagFramesAtFrame.push(inputSeq - 1 - latest[OBS.appliedInputSeq]!);
      m.queriesPerFrame.push(m.queriesThisFrame);
      m.queriesThisFrame = 0;
      const seq = inputSeq++;
      sentAt[seq % sentAt.length] = now();
      const args = hook().applyArgs;
      if (args) effectiveArgs = args;
      if (recording) recordedArgs.set(seq, structuredClone(effectiveArgs));
      m.ticks++;
      send({ type: "tick", dtS, inputSeq: seq, applyArgs: args });
    });
  }

  let audioWanted = true;
  async function launch(record: boolean, audio = audioWanted): Promise<unknown> {
    audioWanted = audio;
    const app = hook();
    generation++;
    outSeq = 0; lastInSeq = -1; fault = null; lastHit = null; haveObservation = false; lastAppliedSeq = inputSeq - 1; m.lastStepId = 0;
    probes = getFdmProfile(app.aircraftId, (app.engineModel ?? undefined) as EngineModelId | undefined).bodyCollisionProbes ?? BODY_COLLISION_PROBES;
    worker ??= new Worker(new URL("./dynamicsShadow.worker.ts", import.meta.url), { type: "module" });
    worker.onmessage = onMessage;
    worker.onerror = event => { fault = `worker error: ${event.message}`; ready?.reject(new Error(fault)); ready = null; };
    start = {
      aircraftId: app.aircraftId, engineModel: app.engineModel,
      dataBaseUrl: new URL(`${import.meta.env.BASE_URL}jsbsim-data`, location.href).href,
      snapshot: captureSimulation(app.sdk), audio, applyArgs: app.applyArgs ? structuredClone(app.applyArgs) : null,
    };
    recording = record; recorded = []; recordedArgs.clear(); effectiveArgs = start.applyArgs;
    recordedArgs.set(-1, structuredClone(start.applyArgs));
    const started = new Promise((resolve, reject) => { ready = { resolve, reject }; });
    send({ type: "start", ...start, record });
    const info = await started;
    lastFrameAt = null;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    return info;
  }

  async function stop(): Promise<void> {
    cancelAnimationFrame(raf);
    if (!worker) return;
    const done = new Promise<void>(resolve => { disposed = resolve; });
    send({ type: "dispose" });
    // Bounded shutdown: an unresponsive worker is terminated and its replies discarded.
    const acknowledged = await Promise.race([done.then(() => true), new Promise<boolean>(resolve => setTimeout(() => resolve(false), 2000))]);
    if (!acknowledged) { worker.terminate(); worker = null; }
    generation++;
  }

  function resetStats(): void {
    for (const key of ["terrainMs", "observationMs", "tickMs", "inputToObservedMs", "lagFramesAtFrame", "queriesPerFrame", "stepsPerObservation"] as const) m[key] = [];
    for (const key of ["queries", "replies", "raycasts", "anchors", "misses", "observations", "audioReadings", "ticks", "staleMessages"] as const) m[key] = 0;
    baseline = workerStats ? { ...workerStats } : null;
    statsSince = now();
  }
  let baseline: WorkerStats | null = null;
  let statsSince = now();

  function stats() {
    const seconds = (now() - statsSince) / 1000;
    const w = workerStats, b = baseline;
    const delta = (key: keyof WorkerStats) => (w?.[key] ?? 0) - (b?.[key] ?? 0);
    return {
      seconds, fault,
      main: {
        terrainMs: stat(m.terrainMs), observationMs: stat(m.observationMs), tickMs: stat(m.tickMs),
        totalMsPerSecond: (m.terrainMs.reduce((a, v) => a + v, 0) + m.observationMs.reduce((a, v) => a + v, 0) + m.tickMs.reduce((a, v) => a + v, 0)) / Math.max(seconds, 1e-9),
        queriesPerFrame: stat(m.queriesPerFrame),
      },
      counts: { queries: m.queries, replies: m.replies, raycasts: m.raycasts, anchors: m.anchors, misses: m.misses,
        observations: m.observations, audioReadings: m.audioReadings, ticks: m.ticks, staleMessages: m.staleMessages },
      latency: { inputToObservedMs: stat(m.inputToObservedMs), lagFramesAtFrame: stat(m.lagFramesAtFrame),
        lagFrameHistogram: m.lagFramesAtFrame.reduce<Record<string, number>>((h, v) => { const k = String(Math.min(v, 6)); h[k] = (h[k] ?? 0) + 1; return h; }, {}) },
      worker: w ? {
        acceptedStepsPerSecond: delta("acceptedSteps") / Math.max(seconds, 1e-9),
        busyMsPerSecond: delta("busyMs") / Math.max(seconds, 1e-9),
        roundTripMeanMs: delta("roundTrips") ? delta("roundTripMs") / delta("roundTrips") : 0,
        roundTripMaxMs: w.maxRoundTripMs,
        droppedMsPerSecond: delta("droppedMs") / Math.max(seconds, 1e-9),
      } : null,
      stepsPerObservation: stat(m.stepsPerObservation),
    };
  }

  /** Restart the worker with recording on, then replay its record on a main-thread reference SDK. */
  async function parity(seconds: number) {
    await stop();
    await launch(true);
    await new Promise(resolve => setTimeout(resolve, seconds * 1000));
    recording = false;
    const records = recorded, argsBySeq = new Map(recordedArgs), begin = start!, workerFault = fault;
    await stop();
    const profile = getFdmProfile(begin.aircraftId, (begin.engineModel ?? undefined) as EngineModelId | undefined);
    const reference = await createJsbsimRuntime({ aircraftId: begin.aircraftId, engineModel: (begin.engineModel ?? undefined) as EngineModelId | undefined,
      dataBaseUrl: begin.dataBaseUrl,
      bootstrap: { latDeg: 0, lonDeg: 0, altFt: 5000, headingDeg: 0, airspeedKts: profile.initialAirspeedKts ?? 100 } });
    try {
      restoreSimulation(reference.sdk, begin.snapshot as Parameters<typeof restoreSimulation>[1]);
      let audio: { read(): unknown } | null = null;
      const installation = begin.audio ? getAircraftAudioInstallation(begin.aircraftId) : null;
      if (installation) {
        const admitted = resolveAircraftAudioInstallation(installation);
        if (admitted.supported) audio = createJsbsimAudioAdapter(reference.sdk, { gearHeightMetres: profile.stance.staticMeters, source: admitted.source });
      }
      const session = createShadowSession(reference.sdk, begin.aircraftId, audio);
      const state = new Float64Array(records[0]?.state.length ?? 0);
      let stateMismatches = 0, audioMismatches = 0, maxAbs = 0, firstMismatch: number | null = null, rejected = 0, missingArgs = 0;
      for (const record of records) {
        const args = argsBySeq.has(record.inputSeq) ? argsBySeq.get(record.inputSeq)! : (missingArgs++, null);
        const outcome = session.step(Number.isFinite(record.terrainHeightMeters) ? record.terrainHeightMeters : null, args);
        if (!outcome.accepted) { rejected++; break; }
        packState(outcome.state, state);
        let same = true;
        for (let index = 0; index < state.length; index++) {
          if (!Object.is(state[index], record.state[index])) { same = false; maxAbs = Math.max(maxAbs, Math.abs(state[index]! - record.state[index]!)); }
        }
        if (!same) { stateMismatches++; firstMismatch ??= record.stepId; }
        const reading = outcome.audio ? JSON.stringify(outcome.audio) : null;
        if (reading !== record.audio) { audioMismatches++; firstMismatch ??= record.stepId; }
      }
      return { steps: records.length, firstStepId: records[0]?.stepId ?? null, lastStepId: records.at(-1)?.stepId ?? null,
        stateMismatches, audioMismatches, maxAbsDifference: maxAbs, firstMismatch, rejected, missingArgs, workerFault,
        audioSteps: records.filter(record => record.audio !== null).length };
    } finally {
      reference.dispose();
    }
  }

  return {
    start: (options: { record?: boolean; audio?: boolean } = {}) => launch(options.record ?? false, options.audio ?? true), stop, stats, resetStats, parity,
    latest: () => (haveObservation ? latest : null),
    previous: () => (haveObservation ? previous : null),
  };
}
