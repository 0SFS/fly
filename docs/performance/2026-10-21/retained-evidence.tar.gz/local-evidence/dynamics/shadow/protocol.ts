/**
 * Experiment protocol between the main thread and the shadow dynamics worker.
 * Every message carries the protocol version, the runtime generation and a
 * per-direction sequence number; receivers reject anything else before it can
 * touch native state. Numeric records use fixed Float64 layouts.
 */
export const PROTOCOL_VERSION = 1;

/** FlightState, in ground-contact's field order. */
export const STATE_FIELDS = [
  "latDeg", "lonDeg", "altMeters", "rollRad", "pitchRad", "headingRad", "airspeedKts",
  "northVelocityFps", "eastVelocityFps", "verticalSpeedFps", "throttleNorm",
] as const;
export const STATE_LENGTH = STATE_FIELDS.length;

/** The per-frame presentation reads that would become observation fields. */
export const SURFACE_FIELDS = [
  "aileronLeftRad", "aileronRightRad", "elevatorRad", "rudderRad", "ruddervatorLeftRad", "ruddervatorRightRad",
  "flapRad", "propellerRadPerSec", "gearDownNorm", "groundSpeedMps", "onGround", "stovlPositionNorm",
  "nozzlePitchRad", "nozzleYawRad",
] as const;
export const INSTRUMENT_PATHS = [
  "velocities/vc-kts", "velocities/h-dot-fps", "aero/alpha-deg", "aero/beta-deg",
  "accelerations/n-pilot-z-norm", "fcs/flap-pos-deg", "simulation/sim-time-sec",
] as const;

export const OBS = {
  state: 0,
  surfaces: STATE_LENGTH,
  tanks: STATE_LENGTH + SURFACE_FIELDS.length,
  pilotG: STATE_LENGTH + SURFACE_FIELDS.length + 4,
  instruments: STATE_LENGTH + SURFACE_FIELDS.length + 5,
  fuelTanks: STATE_LENGTH + SURFACE_FIELDS.length + 5 + INSTRUMENT_PATHS.length,
  stepId: STATE_LENGTH + SURFACE_FIELDS.length + 6 + INSTRUMENT_PATHS.length,
  appliedInputSeq: STATE_LENGTH + SURFACE_FIELDS.length + 7 + INSTRUMENT_PATHS.length,
  length: STATE_LENGTH + SURFACE_FIELDS.length + 8 + INSTRUMENT_PATHS.length,
} as const;

/** One accepted step, for the parity replay: inputs, terrain and outcome. */
export interface StepRecord {
  stepId: number;
  inputSeq: number;
  terrainHeightMeters: number;
  state: Float64Array;
  audio: string | null;
}

export interface TerrainReplyBody {
  requestId: number;
  stepId: number;
  /** The exact-coordinate hit, or null for a miss. */
  sample: { heightMeters: number; revision: number; quality: number | string | null } | null;
  /** The previous anchor re-sampled because the revision changed, else null. */
  anchorHeightMeters: number | null;
  /** Nearest swept-probe hit fraction, or null without a hit or when high. */
  impactFraction: number | null;
  raycasts: number;
}

interface Envelope { v: number; gen: number; seq: number }
export type MainToWorker = Envelope & (
  | { type: "start"; aircraftId: string; engineModel: string | null; dataBaseUrl: string; snapshot: unknown; audio: boolean; applyArgs: unknown[] | null; record: boolean }
  | { type: "tick"; dtS: number; inputSeq: number; applyArgs: unknown[] | null }
  | ({ type: "terrain" } & TerrainReplyBody)
  | { type: "record"; enabled: boolean }
  | { type: "pause"; paused: boolean }
  | { type: "dispose" }
);
export type WorkerToMain = Envelope & (
  | { type: "ready"; startupMs: number; state: Float64Array }
  | { type: "query"; requestId: number; stepId: number; state: Float64Array; prev: Float64Array | null }
  | { type: "observation"; observation: Float64Array; audio: unknown[]; records: StepRecord[]; stats: WorkerStats }
  | { type: "fault"; reason: string }
  | { type: "disposed" }
);

export interface WorkerStats {
  acceptedSteps: number;
  busyMs: number;
  roundTrips: number;
  roundTripMs: number;
  maxRoundTripMs: number;
  droppedMs: number;
}
