#!/usr/bin/env node
/**
 * Flight-dynamics worker, phase A: the current main-thread application's
 * frame cost, split into what a dynamics worker could take and what must stay.
 *
 * Real flight application, JSBSim/WASM, aircraft assets and renderer. Two
 * terrains: FOSS Earth's documented offline mode with flat zero-height ground,
 * and live Google terrain at the W0 Stockton location. Cross-origin isolated,
 * as the deployed service worker makes the page, so performance.now() has its
 * 5 µs resolution rather than 100 µs.
 *
 * Instrumentation exists only in this build (string patches below, each must
 * match exactly once). The CPU sampler is off. Sections are the frame
 * profiler's; per-frame totals come from its trace.
 *
 * Usage (from fly/): node build/perf-20261021/dynamics/baseline.mjs
 *   [--configs=flat-cruise-c172,...] [--runs=5] [--warmup=1] [--seconds=10]
 *   [--no-build] [--build-only] [--variant=main]
 */
import { randomUUID } from "node:crypto";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { build } from "vite";
import { evaluate, openChrome, waitForExpression } from "../../../scripts/headless-chrome.mjs";
import { flightGoogleKey, redactFlightProfile } from "../../../scripts/profile-flight-options.mjs";

const root = "/Users/felg/gh/0sfs/fly";
const here = path.join(root, "build/perf-20261021/dynamics");
const arg = (name, fallback) => process.argv.find(value => value.startsWith(`--${name}=`))?.slice(name.length + 3) ?? fallback;
const variant = arg("variant", "main");
// Optional 4 Hz flight-state samples in each result, to validate a scenario (not for timing runs).
const sampleState = process.argv.includes("--sample-state");
const runsPerConfig = Number(arg("runs", "5"));
const warmupRuns = Number(arg("warmup", "1"));
const windowSeconds = Number(arg("seconds", "10"));
const traceSeconds = Number(arg("trace", "3"));
const out = path.join(here, `bundle-${variant}`);
const fixtureRoot = path.join(here, `fixture-${variant}`);
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const resultsDir = path.join(here, "results", `${variant}-${stamp}`);

const STOCKTON = { lat: 37.91, lon: -121.285, heading: 0 };
const SCK_RUNWAY = { lat: 37.8942, lon: -121.2383, heading: 295 };
const AIRCRAFT = {
  "c172": { id: "cessna-172", airspeed: 110, throttle: 0.65 },
  "f35b": { id: "f-35b", airspeed: 300, throttle: 0.7 },
};
const SCENARIOS = {
  cruise: { height: 1500, airspeed: "cruise", throttle: "cruise" },
  // On the runway at rest, engine idling: contact every step, no probe sweep.
  ground: { height: 0, airspeed: 0, throttle: 0, lowStart: true },
  // On the runway at full throttle: rolling contact and swept body probes, then low flight.
  takeoff: { height: 0, airspeed: 0, throttle: 1, lowStart: true },
  // The app's own autopilot "low" route (C172 and Google only), lowered by a
  // harness patch from 150 m to 60 m above the initial ground so the swept
  // body probes (≤ 150 m) run every step. dev=1 also shows the debug HUD.
  routelow: { route: "low", routeHeight: 60, height: 60, airspeed: "cruise", throttle: "cruise" },
};
const sc_runway = scenario => scenario === "ground" || scenario === "takeoff";
function configOf(name) {
  const [terrain, scenario, aircraft, sound] = name.split("-");
  if (!["flat", "google"].includes(terrain) || !SCENARIOS[scenario] || !AIRCRAFT[aircraft]) throw new Error(`Unknown config ${name}`);
  if (SCENARIOS[scenario].route && (terrain !== "google" || aircraft !== "c172")) throw new Error(`${name}: benchmark routes are C172 on Google terrain only`);
  const place = sc_runway(scenario) && terrain === "google" ? SCK_RUNWAY : STOCKTON;
  const craft = AIRCRAFT[aircraft];
  const sc = SCENARIOS[scenario];
  return {
    name, terrain, scenario, aircraft: craft.id, sound: sound === "sound", lowStart: Boolean(sc.lowStart), route: sc.route ?? null, routeHeight: sc.routeHeight ?? null,
    settle: terrain === "google" ? 15 : 6,
    values: {
      "renderer.mode": "webgl2", "osfs.renderer.attitudeIndicator": "canvas2d",
      "osfs.sound.enabled": sound === "sound", "osfs.start.resume": false,
      "osfs.aircraft.id": craft.id, "osfs.aircraft.generation": craft.id,
      "osfs.start.latitude": place.lat, "osfs.start.longitude": place.lon, "osfs.start.heading": place.heading,
      "osfs.start.heightAboveGround": sc.height,
      "osfs.start.airspeed": sc.airspeed === "cruise" ? craft.airspeed : sc.airspeed,
      "osfs.start.throttle": sc.throttle === "cruise" ? craft.throttle : sc.throttle,
    },
  };
}
const DEFAULT_CONFIGS = [
  "flat-cruise-c172", "flat-cruise-f35b", "flat-ground-c172", "flat-ground-f35b",
  "google-cruise-c172", "google-cruise-f35b", "google-ground-c172", "google-ground-f35b",
  "flat-cruise-f35b-sound", "google-cruise-f35b-sound",
];
const configs = arg("configs", DEFAULT_CONFIGS.join(",")).split(",").map(configOf);

// ---------------------------------------------------------------- build ---
// Each patch names a source suffix, an exact search string (must occur once)
// and its instrumented replacement. `__dynTime` is appended to patched files.
const TIME_HELPER = `\nfunction __dynTime(section, fn) { const p = globalThis.osfsFrameProfiler; const t = p?.clock() ?? 0; try { return fn(); } finally { p?.add(section, t); } }\n`;
const PATCHES = [
  ["/src/flight/physics/fixedStepLoop.ts", [
    ["const result = applyInputs();",
      `const __dynP = globalThis.osfsFrameProfiler; const __dynA = __dynP?.clock() ?? 0; const result = applyInputs(); __dynP?.add("flight/physics/apply inputs", __dynA); const __dynN = __dynP?.clock() ?? 0;`],
    [`const snapshot = typeof sdk.resetToInitialConditions === "function" ? captureSimulation(sdk) : null;
        const success = sdk.run();`,
      `const __dynS = __dynP?.clock() ?? 0; const snapshot = typeof sdk.resetToInitialConditions === "function" ? captureSimulation(sdk) : null; __dynP?.add("flight/physics/native snapshot", __dynS);
        const __dynR = __dynP?.clock() ?? 0; const success = sdk.run(); __dynP?.add("flight/physics/native run", __dynR);`],
    ["onStep?.(currState);",
      `__dynP?.add("flight/physics/native step", __dynN); const __dynC = __dynP?.clock() ?? 0; onStep?.(currState); __dynP?.add("flight/physics/accepted step", __dynC);`],
  ]],
  ["/src/flight/createFlightSimApp.ts", [
    ["flightAudio.publishStep();", `__dynTime("flight/physics/audio publish", () => flightAudio.publishStep());`],
    [`floatingOrigin?.apply(displayState);
    externalTankVisuals?.sync(readExternalFuelTanks(jsbsim.sdk, aircraftId));`,
      `floatingOrigin?.apply(displayState);
    externalTankVisuals?.sync(__dynTime("flight/view/sdk reads", () => readExternalFuelTanks(jsbsim.sdk, aircraftId)));`],
    [`flightAudio.updateView({`, `__dynTime("flight/view/audio view", () => flightAudio.updateView({`],
    [`        heightAboveGroundM: sampledSurfaceHeight === null ? null : displayState.altMeters - sampledSurfaceHeight,
      });`,
      `        heightAboveGroundM: sampledSurfaceHeight === null ? null : displayState.altMeters - sampledSurfaceHeight,
      }));`],
    [`    if (collisionDebugEnabled && wheelSpinMode !== "off") wheelSpinDebugOverlay?.update();
    engineVisuals.read();`,
      `    if (collisionDebugEnabled && wheelSpinMode !== "off") wheelSpinDebugOverlay?.update();
    __dynTime("flight/view/sdk reads", () => engineVisuals.read());`],
    [`const surfaceState = readControlSurfaceState(jsbsim.sdk, aircraftId, {
        nozzlePositionNorm: engineVisuals.nozzlePositionNorm(),
      });`,
      `const surfaceState = __dynTime("flight/view/sdk reads", () => readControlSurfaceState(jsbsim.sdk, aircraftId, {
        nozzlePositionNorm: engineVisuals.nozzlePositionNorm(),
      }));`],
    ["flightRecorder.sample(jsbsim.sdk);", `__dynTime("flight/instruments/recorder", () => flightRecorder.sample(jsbsim.sdk));`],
    ["evaluationInstruments.update(jsbsim.sdk);", `__dynTime("flight/instruments/evaluation", () => evaluationInstruments.update(jsbsim.sdk));`],
    ["const pilotG = readPilotG(jsbsim.sdk);", `const pilotG = __dynTime("flight/instruments/pilot g", () => readPilotG(jsbsim.sdk));`],
    ["engineMonitor.update(jsbsim.sdk, feedbackHeld || worldLoading);",
      `__dynTime("flight/instruments/engine monitor", () => engineMonitor.update(jsbsim.sdk, feedbackHeld || worldLoading));`],
    ["controlPanel?.update(createPanelSnapshot(displayState));",
      `__dynTime("flight/panels/control panel", () => controlPanel?.update(createPanelSnapshot(displayState)));`],
  ]],
];
const SHADOW = variant === "shadow" || variant === "paired";
// Shadow variant: the app exposes its SDK, scene query and latest control
// arguments, so a shadow worker can run the same steps beside it.
const APPLY_HELPER = `\nfunction __dynApply(fn, sdk, ...rest) { const hook = globalThis.__dynHook; if (hook) hook.applyArgs = rest; return fn(sdk, ...rest); }\n`;
// Every variant: a runway start may skip the 1 km spawn clearance (startup placement only).
PATCHES.find(([suffix]) => suffix === "/src/flight/createFlightSimApp.ts")[1].push(
  ["altitudeAboveGroundMeters: startHeightMeters, clearanceMeters: benchmarkRoute ? 0 : 1000",
    "altitudeAboveGroundMeters: startHeightMeters, clearanceMeters: benchmarkRoute || globalThis.__dyn?.lowStart ? 0 : 1000"],
);
// Every variant: a configuration may lower the low benchmark route (default 150 m).
PATCHES.push(["/src/flight/benchmarkRoutes.ts", [
  ["heightAboveGroundMeters: 150, airspeedKts: 110", "heightAboveGroundMeters: globalThis.__dyn?.routeHeight ?? 150, airspeedKts: 110"],
]]);
if (SHADOW) PATCHES.find(([suffix]) => suffix === "/src/flight/createFlightSimApp.ts")[1].push(
  ["const flightSurface = createFrameSurfaceQuery(runtime.surface);",
    "const flightSurface = createFrameSurfaceQuery(runtime.surface); globalThis.__dynHook = { sdk: jsbsim.sdk, surface: runtime.surface, aircraftId: initialAircraftId, engineModel: jsbsim.identity.engineModel ?? null, applyArgs: null };"],
  ["applyFlightControls(\n        jsbsim.sdk,", "__dynApply(applyFlightControls,\n        jsbsim.sdk,"],
);
function instrument(code, id) {
  const entry = PATCHES.find(([suffix]) => id.endsWith(suffix));
  if (!entry) return null;
  let patched = code;
  for (const [search, replacement] of entry[1]) {
    const count = patched.split(search).length - 1;
    if (count !== 1) throw new Error(`Instrumentation patch for ${entry[0]} matched ${count} times: ${search.slice(0, 80)}`);
    patched = patched.replace(search, () => replacement);
  }
  return patched + TIME_HELPER + (SHADOW && id.endsWith("/src/flight/createFlightSimApp.ts") ? APPLY_HELPER : "");
}

await mkdir(fixtureRoot, { recursive: true });
const source = relative => JSON.stringify(path.join(root, relative));
const runtimeWrapper = path.join(fixtureRoot, "dynamics-runtime.ts");
// The flat fixture is FOSS Earth's documented offline mode with zero-height
// ground; the Google fixture passes the runtime through unchanged.
await writeFile(runtimeWrapper, `
export * from ${source("node_modules/foss-earth/src/runtime/index.ts")};
import {createBabylonRuntime as create} from ${source("node_modules/foss-earth/src/runtime/index.ts")};
export async function createBabylonRuntime(canvas,options){
 const flat=window.__dyn?.fixture==='flat';
 return create(canvas,flat?{...options,googleApiKey:null,preferGoogleTiles:false,rasterBaseMap:null,getSurfaceHeightMeters:()=>0}:options);
}
`);
await writeFile(path.join(fixtureRoot, "entry.ts"), String.raw`
${SHADOW ? `import {createDynamicsShadow} from ${JSON.stringify(path.join(here, "shadow/dynamicsShadow.ts"))};window.__dynShadow=createDynamicsShadow();` : ""}
import ${source("src/styles/globe.css")};
import ${source("src/styles/flight.css")};
import {getAppSettings} from 'foss-earth/settings';
const test=window.__dyn??={};Object.assign(test,{ready:false,error:null});
getAppSettings(); // As in main.tsx, diagnostics precede aircraft registration.
const options=test.fixture==='flat'?{googleApiKey:null,preferGoogleTiles:false}:{};
import(${source("src/flight/createFlightSimApp.ts")}).then(({createFlightSimApp})=>createFlightSimApp(document.getElementById('root'),options)).then(app=>{
 test.app=app;test.runtime=app.runtime;test.ready=true;
}).catch(error=>{const explain=e=>(e.stack??String(e))+(e.cause?'\nCaused by: '+explain(e.cause):'')+(e.errors?'\n'+e.errors.map(explain).join('\n'):'');test.error=explain(error);test.ready=true;});
`);
await writeFile(path.join(fixtureRoot, "index.html"), '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Flight dynamics baseline</title></head><body><div id="root"></div><script type="module" src="/entry.ts"></script></body></html>');
if (!process.argv.includes("--no-build")) {
  const { default: appConfig } = await import("../../../vite.config.ts");
  await build({
    ...appConfig, configFile: false,
    plugins: [
      ...appConfig.plugins.filter(plugin => !["foss-earth-boot-terminal", "copy-index-to-pages-paths", "foss-earth-ui-app-files"].includes(plugin?.name)),
      { name: "dynamics-baseline-instrumentation", enforce: "pre", transform: (code, id) => instrument(code, id) },
      { name: "observe-real-flight-snapshots", enforce: "pre", transform(code, id) {
        if (!id.endsWith("/src/flight/hud/createFlightControlPanel.tsx")) return null;
        return code.replace("let snapshot = initialSnapshot;", "let snapshot = initialSnapshot; window.__dyn.snapshot = snapshot;")
          .replace("snapshot = nextSnapshot;", "snapshot = nextSnapshot; window.__dyn.snapshot = snapshot;");
      } },
    ],
    root: fixtureRoot, publicDir: false, base: "/", logLevel: "warn",
    resolve: { ...appConfig.resolve, alias: [{ find: /^foss-earth\/runtime$/, replacement: runtimeWrapper }] },
    build: { outDir: out, emptyOutDir: true, minify: false },
  });
}
if (process.argv.includes("--build-only")) { console.log("Build ready", out); process.exit(0); }

// ------------------------------------------------------------- analysis ---
const CONCURRENT = new Set(["gpu", "background"]);
const stats = values => {
  if (!values.length) return { mean: 0, p50: 0, p95: 0, p99: 0, max: 0 };
  const sorted = Float64Array.from(values).sort();
  const at = rank => sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * rank))];
  return { mean: sorted.reduce((sum, value) => sum + value, 0) / sorted.length, p50: at(0.5), p95: at(0.95), p99: at(0.99), max: sorted[sorted.length - 1] };
};
/** Per-frame decomposition from the profiler's trace. */
function decompose(frames) {
  const rows = frames.map(frame => {
    const s = name => frame.sections[name] ?? 0;
    let total = 0;
    for (const [section, value] of Object.entries(frame.sections)) if (!section.includes("/") && !CONCURRENT.has(section)) total += value;
    const contact = s("flight/physics/terrain contact"), collision = s("flight/physics/collision");
    const applyInputs = s("flight/physics/apply inputs");
    const controls = Math.max(0, applyInputs - contact - collision);
    const nativeStep = s("flight/physics/native step"), acceptedStep = s("flight/physics/accepted step");
    const viewReads = s("flight/view/sdk reads"), instruments = s("flight/instruments");
    const instrumentReads = s("flight/instruments/recorder") + s("flight/instruments/evaluation") + s("flight/instruments/pilot g") + s("flight/instruments/engine monitor");
    // Upper bound: every movable part leaves the main thread at no cost.
    const movable = controls + nativeStep + acceptedStep + viewReads + instrumentReads;
    // Strict core: only the fixed step itself and its native snapshot/run.
    const core = nativeStep;
    return {
      interval: frame.intervalMs, total, render: s("render"), flight: s("flight"), physics: s("flight/physics"),
      contact, collision, controls, nativeStep, nativeRun: s("flight/physics/native run"), nativeSnapshot: s("flight/physics/native snapshot"),
      acceptedStep, audioPublish: s("flight/physics/audio publish"), audioView: s("flight/view/audio view"), feedback: s("flight/feedback"),
      view: s("flight/view"), viewReads, hud: s("flight/hud"), instruments, instrumentReads, panels: s("flight/panels"),
      terrain: s("flight/terrain"), gpu: s("gpu"), steps: 0,
      movable, residualAfterMovable: total - movable, residualAfterCore: total - core,
      dynamics: s("dynamics"), dynamicsTerrain: s("dynamics/terrain"), dynamicsObservation: s("dynamics/observation"), dynamicsTick: s("dynamics/tick"),
      // Shadow variant: the frame if the worker had replaced the app's own
      // movable work, contact and collision (its terrain service stays counted).
      workerPathEstimate: total - movable - contact - collision,
    };
  });
  const keys = Object.keys(rows[0] ?? {});
  const summary = Object.fromEntries(keys.map(key => [key, stats(rows.map(row => row[key]))]));
  // Frame-wise: what p95 would be if the movable work left for free.
  summary.upperBoundSaving = {
    mean: summary.total.mean - summary.residualAfterMovable.mean,
    p95: summary.total.p95 - summary.residualAfterMovable.p95,
    p95Fraction: summary.total.p95 > 0 ? (summary.total.p95 - summary.residualAfterMovable.p95) / summary.total.p95 : 0,
    coreMean: summary.total.mean - summary.residualAfterCore.mean,
    coreP95Fraction: summary.total.p95 > 0 ? (summary.total.p95 - summary.residualAfterCore.p95) / summary.total.p95 : 0,
  };
  summary.framesOver20ms = rows.filter(row => row.interval > 20).length;
  summary.frames = rows.length;
  return summary;
}
/** Main-thread and worker busy time from a Chrome trace. */
function analyseTrace(events) {
  const threads = new Map();
  for (const event of events) if (event.ph === "M" && event.name === "thread_name") threads.set(`${event.pid}:${event.tid}`, event.args.name);
  const byThread = new Map();
  for (const event of events) {
    if (event.ph !== "X" || typeof event.dur !== "number") continue;
    const key = `${event.pid}:${event.tid}`;
    (byThread.get(key) ?? byThread.set(key, []).get(key)).push(event);
  }
  // The page's renderer main thread is the one firing animation frames.
  let main = null, best = -1;
  const rendererMains = [];
  for (const [key, list] of byThread) {
    if (threads.get(key) !== "CrRendererMain") continue;
    const frames = list.filter(event => event.name === "FireAnimationFrame").length;
    const busy = list.filter(event => event.name === "ThreadControllerImpl::RunTask" || event.name === "RunTask").reduce((sum, event) => sum + event.dur, 0) / 1000;
    rendererMains.push({ thread: key, frames, busyMs: busy });
    // The page's main thread both fires animation frames and does the most work.
    const score = frames > 30 ? busy : -1;
    if (score > best) { best = score; main = key; }
  }
  if (!main) return null;
  const busyOf = list => {
    const tasks = list.filter(event => event.name === "ThreadControllerImpl::RunTask" || event.name === "RunTask").map(event => [event.ts, event.ts + event.dur]).sort((a, b) => a[0] - b[0]);
    const merged = [];
    for (const [start, end] of tasks) {
      const last = merged[merged.length - 1];
      if (last && start <= last[1]) last[1] = Math.max(last[1], end); else merged.push([start, end]);
    }
    return merged;
  };
  const mainList = byThread.get(main);
  const merged = busyOf(mainList);
  // Several rAF callbacks fire per frame; a frame starts with the task that runs the first of them.
  const frameStarts = [...new Set(mainList.filter(event => event.name === "FireAnimationFrame")
    .map(event => merged.find(([start, end]) => event.ts >= start && event.ts <= end)?.[0] ?? event.ts))].sort((a, b) => a - b);
  const perFrame = [];
  for (let index = 1; index < frameStarts.length; index++) {
    const from = frameStarts[index - 1], to = frameStarts[index];
    let busy = 0;
    for (const [start, end] of merged) busy += Math.max(0, Math.min(end, to) - Math.max(start, from));
    perFrame.push(busy / 1000);
  }
  const span = frameStarts.length > 1 ? (frameStarts[frameStarts.length - 1] - frameStarts[0]) / 1e6 : 0;
  const gcNames = new Set(["MinorGC", "MajorGC", "V8.GCScavenger", "V8.GCCompactor", "V8.GCFinalizeMC", "V8.GC_MC_BACKGROUND", "BlinkGC.AtomicPhase"]);
  const gcMs = mainList.filter(event => event.name === "MinorGC" || event.name === "MajorGC").reduce((sum, event) => sum + event.dur / 1000, 0);
  const otherThreads = {};
  const workerThreads = [];
  const mainPid = main.split(":")[0];
  for (const [key, list] of byThread) {
    if (key === main || key.split(":")[0] !== mainPid) continue;
    const name = threads.get(key) ?? key;
    if (!/Worker|Worklet/i.test(name)) continue;
    const busy = busyOf(list).reduce((sum, [start, end]) => sum + end - start, 0) / 1000;
    otherThreads[name] = (otherThreads[name] ?? 0) + busy;
    const tasks = list.filter(event => event.name === "ThreadControllerImpl::RunTask" || event.name === "RunTask").length;
    if (span > 0) workerThreads.push({ name, busyMsPerSecond: busy / span, tasksPerSecond: tasks / span });
  }
  workerThreads.sort((a, b) => b.busyMsPerSecond - a.busyMsPerSecond);
  return {
    rendererMains, seconds: span, frames: perFrame.length, mainBusyPerFrame: stats(perFrame),
    mainGcMsPerSecond: span > 0 ? gcMs / span : 0, gcEventNamesSeen: [...new Set(mainList.filter(event => gcNames.has(event.name)).map(event => event.name))],
    workerBusyMsPerSecond: Object.fromEntries(Object.entries(otherThreads).map(([name, ms]) => [name, span > 0 ? ms / span : 0])),
    workerThreads,
  };
}

// ---------------------------------------------------------------- serve ---
const ORIGIN = "https://0sfs.test";
const mime = { ".html": "text/html", ".js": "text/javascript", ".mjs": "text/javascript", ".wasm": "application/wasm", ".css": "text/css", ".json": "application/json", ".xml": "text/xml", ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".woff2": "font/woff2", ".glb": "model/gltf-binary", ".ktx2": "image/ktx2" };
// The deployed service worker isolates the page with COEP require-corp; so does this server.
const ISOLATION = [{ name: "Cross-Origin-Opener-Policy", value: "same-origin" }, { name: "Cross-Origin-Embedder-Policy", value: "require-corp" }, { name: "Cross-Origin-Resource-Policy", value: "same-origin" }];
const needsKey = configs.some(config => config.terrain === "google");
const googleKey = needsKey ? await flightGoogleKey() : null;
if (needsKey && !googleKey) throw new Error("Google terrain needs FOSS_EARTH_GOOGLE_KEY in an agreed .env.local file.");
const safe = value => redactFlightProfile(value, [googleKey]);

await mkdir(resultsDir, { recursive: true });
const report = { variant, generatedAt: new Date().toISOString(), runsPerConfig, warmupRuns, windowSeconds, traceSeconds,
  scope: "Headless Chrome (new headless), WebGL2 globe, canvas2d attitude indicator, 1280x800 DPR 1, cross-origin isolated, CPU sampler off, no pilot input.",
  configs: {} };
let chrome = null;
const profileDirectories = [];
const sessions = new Map();
const traceChunks = [];
let traceDone = null;
const stop = () => { if (chrome) void chrome.close().catch(() => {}); };
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
try {
  for (const config of configs) {
    const profileDirectory = path.join(here, `chrome-profile-${randomUUID()}`);
    profileDirectories.push(profileDirectory);
    chrome = await openChrome(profileDirectory, undefined, ["--autoplay-policy=no-user-gesture-required"], { headed: false });
    chrome.onEvent(message => {
      if (message.method === "Tracing.dataCollected") { traceChunks.push(...message.params.value); return; }
      if (message.method === "Tracing.tracingComplete") { traceDone?.(); return; }
      const current = sessions.get(message.sessionId);
      if (!current) return;
      if (message.method === "Runtime.exceptionThrown") current.exceptions.push(safe(message.params.exceptionDetails.exception?.description ?? message.params.exceptionDetails.text));
      if (message.method !== "Fetch.requestPaused") return;
      void (async () => {
        const { requestId, request } = message.params;
        const url = new URL(request.url);
        if (url.origin !== ORIGIN) {
          if (config.terrain === "flat") { await chrome.send("Fetch.failRequest", { requestId, errorReason: "BlockedByClient" }, message.sessionId); return; }
          current.external++;
          await chrome.send("Fetch.continueRequest", { requestId }, message.sessionId);
          return;
        }
        const base = /^\/(aircraft|jsbsim-data)\//.test(url.pathname) ? path.join(root, "public") : out;
        const file = path.resolve(base, "." + (url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname)));
        try {
          if (!file.startsWith(base + path.sep)) throw Error("Invalid path");
          const bytes = await readFile(file);
          await chrome.send("Fetch.fulfillRequest", { requestId, responseCode: 200, responseHeaders: [{ name: "Content-Type", value: mime[path.extname(file)] ?? "application/octet-stream" }, ...ISOLATION], body: bytes.toString("base64") }, message.sessionId);
        } catch { await chrome.send("Fetch.fulfillRequest", { requestId, responseCode: 404, responseHeaders: ISOLATION, body: "" }, message.sessionId); }
      })().catch(error => current.exceptions.push(safe(`interception: ${error.message}`)));
    });
    const configReport = report.configs[config.name] = { settings: safe(config.values), terrain: config.terrain, scenario: config.scenario, aircraft: config.aircraft, sound: config.sound, runs: [] };
    const modes = variant === "paired" ? ["main", "shadow"] : [variant === "shadow" ? "shadow" : "main"];
    const schedule = [];
    for (let index = 0; index < warmupRuns; index++) for (const mode of modes) schedule.push({ mode, warmup: true, run: 0 });
    for (let index = 0; index < runsPerConfig; index++) for (const mode of index % 2 ? [...modes].reverse() : modes) schedule.push({ mode, warmup: false, run: index + 1 });
    let parityDone = false;
    for (const { mode, warmup, run: runNumber } of schedule) {
      const shadowMode = mode === "shadow";
      const current = { exceptions: [], external: 0 };
      const { targetId } = await chrome.send("Target.createTarget", { url: "about:blank" });
      const { sessionId } = await chrome.send("Target.attachToTarget", { targetId, flatten: true });
      sessions.set(sessionId, current);
      const run = expression => evaluate(chrome, sessionId, expression);
      await chrome.send("Runtime.enable", {}, sessionId);
      await chrome.send("Page.enable", {}, sessionId);
      await chrome.send("Performance.enable", { timeDomain: "timeTicks" }, sessionId);
      await chrome.send("Fetch.enable", { patterns: [{ urlPattern: "*" }] }, sessionId);
      await chrome.send("Emulation.setDeviceMetricsOverride", { width: 1280, height: 800, deviceScaleFactor: 1, mobile: false }, sessionId);
      const values = { ...config.values, ...(config.terrain === "google" ? { "map.source.googleKey": googleKey, "map.source.basemap": "google" } : {}) };
      await chrome.send("Page.addScriptToEvaluateOnNewDocument", { source: `if(location.origin==='${ORIGIN}'){window.__dyn={fixture:${JSON.stringify(config.terrain)},lowStart:${config.lowStart},routeHeight:${config.routeHeight},audioContexts:[]};const AC=window.AudioContext;window.AudioContext=class extends AC{constructor(...a){super(...a);window.__dyn.audioContexts.push(this);}};localStorage.setItem('foss-earth.settings.v1',${JSON.stringify(JSON.stringify({ version: 1, values }))});}` }, sessionId);
      await chrome.send("Page.navigate", { url: `${ORIGIN}/?flightPerf=1${config.route ? `&dev=1&route=${config.route}` : ""}` }, sessionId);
      const label = `${config.name}${modes.length > 1 ? ` ${mode}` : ""} ${warmup ? "warmup" : `run ${runNumber}/${runsPerConfig}`}`;
      try {
        await waitForExpression(chrome, sessionId, "window.__dyn?.ready===true", 180000);
        const error = await run("window.__dyn.error");
        if (error) throw new Error(error);
        await waitForExpression(chrome, sessionId, "window.__dyn.snapshot?.modelStatus==='ready' && (window.osfsFrameProfiler?.summary().frames ?? 0) > 120", 180000);
        if (sampleState) await run(`(() => { const t0 = performance.now(); window.__dyn.samples = []; setInterval(() => { const s = window.__dyn.snapshot; const f = s?.flightState; if (f) window.__dyn.samples.push({ t: +((performance.now() - t0) / 1000).toFixed(2), paused: s.paused, lat: f.latDeg, lon: f.lonDeg, alt: +f.altMeters.toFixed(2), roll: +(f.rollRad * 57.2958).toFixed(1), pitch: +(f.pitchRad * 57.2958).toFixed(1), hdg: +(f.headingRad * 57.2958).toFixed(1), kts: +f.airspeedKts.toFixed(1), vs: +f.verticalSpeedFps.toFixed(1), thr: f.throttleNorm }); }, 250); return true; })()`);
        // One identical click in every configuration: it unlocks audio where
        // sound is on and keeps the input trace the same everywhere else.
        for (const type of ["mousePressed", "mouseReleased"]) await chrome.send("Input.dispatchMouseEvent", { type, x: 640, y: 400, button: "left", clickCount: 1 }, sessionId);
        const settleStarted = Date.now();
        let shadowStart = null;
        if (shadowMode) {
          // Inside the same settle period, so the measured window starts at the same time as main's.
          shadowStart = await run(`window.__dynShadow.start({ audio: ${config.sound} }).then(info => info, error => ({ error: String(error && error.stack || error) }))`);
          if (shadowStart?.error) throw new Error(`shadow start: ${shadowStart.error}`);
        }
        await new Promise(resolve => setTimeout(resolve, Math.max(0, config.settle * 1000 - (Date.now() - settleStarted))));
        if (shadowMode) {
          const fault = await run("window.__dynShadow.stats().fault");
          if (fault) throw new Error(`shadow fault: ${fault}`);
        }
        if (warmup) { console.log(`${label}: done`); continue; }
        const before = (await chrome.send("Performance.getMetrics", {}, sessionId)).metrics;
        await run(`(() => { const p = window.osfsFrameProfiler; p.configure({ windowFrames: ${Math.ceil(windowSeconds * 60 * 1.5)}, traceFrames: ${Math.ceil(windowSeconds * 60 * 1.5)} }); p.enabled = false; p.enabled = true; p.reset(); window.__dynShadow?.resetStats(); return true; })()`);
        const startedAt = Date.now();
        await new Promise(resolve => setTimeout(resolve, windowSeconds * 1000));
        const measured = await run(`(() => { const p = window.osfsFrameProfiler; const s = window.__dyn.snapshot; return { summary: p.summary(), trace: p.trace().frames, isolated: crossOriginIsolated, snapshot: s && { modelStatus: s.modelStatus, paused: s.paused, flightState: s.flightState, sound: s.sound }, aircraft: window.osfsJsbsimBuild?.aircraftId ?? null, mode: window.__dyn.runtime?.status?.mode ?? null, heap: performance.memory?.usedJSHeapSize ?? null, audio: { contexts: window.__dyn.audioContexts.map(c => c.state), hidden: document.hidden, activated: navigator.userActivation?.hasBeenActive ?? null }, shadow: window.__dynShadow?.stats() ?? null }; })()`);
        const elapsed = (Date.now() - startedAt) / 1000;
        const after = (await chrome.send("Performance.getMetrics", {}, sessionId)).metrics;
        const metric = (list, name) => list.find(item => item.name === name)?.value ?? NaN;
        const frames = measured.trace.length;
        const cdp = Object.fromEntries(["TaskDuration", "ScriptDuration", "LayoutDuration", "RecalcStyleDuration"].map(name => [name, (metric(after, name) - metric(before, name)) * 1000 / Math.max(1, frames)]));
        cdp.seconds = elapsed;
        cdp.heapDeltaBytes = metric(after, "JSHeapUsedSize") - metric(before, "JSHeapUsedSize");
        // A separate traced window, so tracing overhead stays out of the profiler numbers.
        traceChunks.length = 0;
        await chrome.send("Tracing.start", { categories: "toplevel,devtools.timeline", transferMode: "ReportEvents" });
        await new Promise(resolve => setTimeout(resolve, traceSeconds * 1000));
        const finished = new Promise(resolve => { traceDone = resolve; });
        await chrome.send("Tracing.end");
        await finished;
        const traced = analyseTrace(traceChunks);
        // Transport parity, once per configuration and after every timed window.
        const parity = shadowMode && !parityDone ? await run(`window.__dynShadow.parity(5).then(value => value, error => ({ error: String(error && error.stack || error) }))`) : null;
        const decomposition = decompose(measured.trace);
        if (parity) parityDone = true;
        const samples = sampleState ? await run("window.__dyn.samples") : undefined;
        const result = { samples, run: runNumber, mode, isolated: measured.isolated, aircraftLoaded: measured.aircraft, runtimeMode: measured.mode,
          snapshot: measured.snapshot, audio: measured.audio, frames, decomposition, shadow: measured.shadow, shadowStart, parity, cdpPerFrame: cdp, trace: traced, externalRequests: current.external,
          exceptions: current.exceptions, sections: measured.summary.sections.map(({ section, meanMs, p95Ms, activeFrames }) => ({ section, meanMs, p95Ms, activeFrames })) };
        configReport.runs.push(result);
        await writeFile(path.join(resultsDir, `${config.name}${modes.length > 1 ? `-${mode}` : ""}-run${result.run}.json`), JSON.stringify(safe({ ...result, profilerTrace: measured.trace }), null, 0));
        const d = decomposition;
        console.log(`${label}: isolated=${measured.isolated} mode=${measured.mode} frames=${frames} interval ${d.interval.mean.toFixed(2)}ms | total ${d.total.mean.toFixed(3)} p95 ${d.total.p95.toFixed(3)} | physics ${d.physics.mean.toFixed(3)} (native ${d.nativeStep.mean.toFixed(3)}, run ${d.nativeRun.mean.toFixed(3)}, controls ${d.controls.mean.toFixed(3)}, contact ${d.contact.mean.toFixed(3)}, collision ${d.collision.mean.toFixed(3)}, accepted ${d.acceptedStep.mean.toFixed(3)}) | movable ${d.movable.mean.toFixed(3)} saving p95 ${(d.upperBoundSaving.p95Fraction * 100).toFixed(1)}% | CDP task ${cdp.TaskDuration.toFixed(3)} | trace main p95 ${traced?.mainBusyPerFrame.p95.toFixed(3)} gc ${traced?.mainGcMsPerSecond.toFixed(2)}ms/s`);
        if (shadowMode) {
          const sh = measured.shadow;
          console.log(`  shadow: main dynamics ${d.dynamics.mean.toFixed(3)} p95 ${d.dynamics.p95.toFixed(3)} (terrain ${d.dynamicsTerrain.mean.toFixed(3)}, obs ${d.dynamicsObservation.mean.toFixed(3)}, tick ${d.dynamicsTick.mean.toFixed(3)}) | estimate ${d.workerPathEstimate.mean.toFixed(3)} p95 ${d.workerPathEstimate.p95.toFixed(3)} | worker ${sh?.worker?.acceptedStepsPerSecond.toFixed(1)} steps/s busy ${sh?.worker?.busyMsPerSecond.toFixed(1)}ms/s rt ${sh?.worker?.roundTripMeanMs.toFixed(3)}/${sh?.worker?.roundTripMaxMs.toFixed(2)}ms dropped ${sh?.worker?.droppedMsPerSecond.toFixed(1)}ms/s | lag ${JSON.stringify(sh?.latency.lagFrameHistogram)} in->obs p50 ${sh?.latency.inputToObservedMs.p50.toFixed(2)} p95 ${sh?.latency.inputToObservedMs.p95.toFixed(2)} | fault ${sh?.fault}${parity ? ` | parity ${JSON.stringify(parity)}` : ""}`);
        }
      } catch (error) {
        const shot = await chrome.send("Page.captureScreenshot", { format: "png" }, sessionId).catch(() => null);
        if (shot) await writeFile(path.join(resultsDir, `${config.name}-${mode}-run${runNumber}${warmup ? "-warmup" : ""}-failed.png`), Buffer.from(shot.data, "base64"));
        configReport.runs.push({ run: runNumber, mode, warmup, error: safe(error.message), exceptions: current.exceptions });
        console.log(`${label}: FAILED ${safe(error.message)} ${current.exceptions.slice(0, 3).join(" | ")}`);
      } finally {
        await run("window.__dyn?.app?.destroy?.()").catch(() => {});
        await chrome.send("Target.closeTarget", { targetId }).catch(() => {});
        sessions.delete(sessionId);
      }
    }
    await chrome.close();
    chrome = null;
    await rm(profileDirectory, { recursive: true, force: true });
    await writeFile(path.join(resultsDir, "report.json"), JSON.stringify(safe(report), null, 2));
  }
} finally {
  try { await chrome?.close(); } finally {
    for (const directory of profileDirectories) await rm(directory, { recursive: true, force: true });
    await writeFile(path.join(resultsDir, "report.json"), JSON.stringify(safe(report), null, 2));
    console.log("Report", path.relative(root, path.join(resultsDir, "report.json")));
  }
}
