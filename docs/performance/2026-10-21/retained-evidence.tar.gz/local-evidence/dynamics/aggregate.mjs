#!/usr/bin/env node
/**
 * Aggregate the dynamics baseline (main) and shadow-worker runs: per
 * configuration mean, range and 95% confidence interval across runs, and the
 * shipping gate from flight-dynamics-worker.md.
 *
 *   node build/perf-20261021/dynamics/aggregate.mjs results/main-… [results/shadow-…|results/paired-…]
 *
 * A paired directory holds both modes from one bundle (ABBA order); each
 * result names its mode, and the measured saving is then also given as a
 * paired difference by run number.
 */
import { readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const here = path.dirname(new URL(import.meta.url).pathname);
const dirs = process.argv.slice(2).map(dir => path.resolve(here, dir));
const T975 = [NaN, 12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228];
const across = values => {
  const v = values.filter(Number.isFinite);
  const n = v.length;
  if (!n) return null;
  const mean = v.reduce((a, b) => a + b, 0) / n;
  const sd = n > 1 ? Math.sqrt(v.reduce((a, b) => a + (b - mean) ** 2, 0) / (n - 1)) : NaN;
  return { n, mean, sd, min: Math.min(...v), max: Math.max(...v), ci95: n > 1 ? T975[Math.min(n - 1, 10)] * sd / Math.sqrt(n) : NaN };
};
/** Welch difference a − b with an approximate 95% interval. */
const difference = (a, b) => {
  if (!a || !b) return null;
  const se = Math.sqrt((a.sd ** 2) / a.n + (b.sd ** 2) / b.n);
  const df = se ** 4 / (((a.sd ** 2 / a.n) ** 2) / (a.n - 1) + ((b.sd ** 2 / b.n) ** 2) / (b.n - 1));
  const t = T975[Math.min(Math.max(1, Math.floor(df)), 10)];
  return { mean: a.mean - b.mean, ci95: t * se };
};

const FIELDS = {
  intervalMs: r => r.decomposition.interval.mean,
  totalMean: r => r.decomposition.total.mean, totalP95: r => r.decomposition.total.p95,
  render: r => r.decomposition.render.mean, gpu: r => r.decomposition.gpu.mean,
  flight: r => r.decomposition.flight.mean, physics: r => r.decomposition.physics.mean,
  contact: r => r.decomposition.contact.mean, collision: r => r.decomposition.collision.mean,
  controls: r => r.decomposition.controls.mean, nativeStep: r => r.decomposition.nativeStep.mean,
  nativeRun: r => r.decomposition.nativeRun.mean, nativeSnapshot: r => r.decomposition.nativeSnapshot.mean,
  acceptedStep: r => r.decomposition.acceptedStep.mean, audioPublish: r => r.decomposition.audioPublish.mean,
  audioView: r => r.decomposition.audioView.mean, view: r => r.decomposition.view.mean, viewReads: r => r.decomposition.viewReads.mean,
  hud: r => r.decomposition.hud.mean, instruments: r => r.decomposition.instruments.mean, instrumentReads: r => r.decomposition.instrumentReads.mean,
  panels: r => r.decomposition.panels.mean, terrain: r => r.decomposition.terrain.mean,
  movable: r => r.decomposition.movable.mean, movableP95: r => r.decomposition.movable.p95,
  upperSavingMean: r => r.decomposition.upperBoundSaving.mean, upperSavingP95: r => r.decomposition.upperBoundSaving.p95,
  upperSavingP95Fraction: r => r.decomposition.upperBoundSaving.p95Fraction,
  residualP95: r => r.decomposition.residualAfterMovable.p95,
  framesOver20ms: r => r.decomposition.framesOver20ms,
  cdpTask: r => r.cdpPerFrame.TaskDuration, cdpScript: r => r.cdpPerFrame.ScriptDuration,
  traceMainMean: r => r.trace?.mainBusyPerFrame.mean, traceMainP95: r => r.trace?.mainBusyPerFrame.p95,
  gcMsPerSecond: r => r.trace?.mainGcMsPerSecond,
  workersMsPerSecond: r => Object.values(r.trace?.workerBusyMsPerSecond ?? {}).reduce((a, b) => a + b, 0),
  // Shadow only.
  dynamics: r => r.decomposition.dynamics?.mean, dynamicsP95: r => r.decomposition.dynamics?.p95,
  dynamicsTerrain: r => r.decomposition.dynamicsTerrain?.mean, dynamicsObservation: r => r.decomposition.dynamicsObservation?.mean,
  dynamicsTick: r => r.decomposition.dynamicsTick?.mean,
  estimateMean: r => r.decomposition.workerPathEstimate?.mean, estimateP95: r => r.decomposition.workerPathEstimate?.p95,
  cdpEstimate: r => r.decomposition.dynamics ? r.cdpPerFrame.TaskDuration - r.decomposition.movable.mean - r.decomposition.contact.mean - r.decomposition.collision.mean : NaN,
  workerStepsPerSecond: r => r.shadow?.worker?.acceptedStepsPerSecond, workerBusyMsPerSecond: r => r.shadow?.worker?.busyMsPerSecond,
  roundTripMeanMs: r => r.shadow?.worker?.roundTripMeanMs, roundTripMaxMs: r => r.shadow?.worker?.roundTripMaxMs,
  droppedMsPerSecond: r => r.shadow?.worker?.droppedMsPerSecond,
  inputToObservedP50: r => r.shadow?.latency.inputToObservedMs.p50, inputToObservedP95: r => r.shadow?.latency.inputToObservedMs.p95,
  lagFramesMean: r => r.shadow?.latency.lagFramesAtFrame.mean, queriesPerFrame: r => r.shadow?.main.queriesPerFrame.mean,
  raycastsPerSecond: r => r.shadow ? r.shadow.counts.raycasts / r.shadow.seconds : NaN,
};

const variants = {};
for (const dir of dirs) {
  const dirVariant = path.basename(dir).split("-")[0];
  const files = (await readdir(dir)).filter(file => /-run\d+\.json$/.test(file));
  for (const file of files) {
    const config = file.replace(/(-main|-shadow)?-run\d+\.json$/, "");
    const result = JSON.parse(await readFile(path.join(dir, file), "utf8"));
    if (!result.decomposition) continue;
    delete result.profilerTrace;
    // Older baseline results used "mode" for the runtime terrain mode.
    const variant = result.mode === "main" || result.mode === "shadow" ? result.mode : dirVariant;
    ((variants[variant] ??= {})[config] ??= []).push(result);
  }
}

const summary = {};
for (const [variant, configs] of Object.entries(variants)) {
  for (const [config, runs] of Object.entries(configs)) {
    const row = (summary[config] ??= {})[variant] = { runs: runs.length };
    for (const [field, read] of Object.entries(FIELDS)) {
      const value = across(runs.map(run => { try { return read(run); } catch { return NaN; } }));
      if (value) row[field] = value;
    }
    row.parity = runs.map(run => run.parity).filter(Boolean);
    row.faults = runs.map(run => run.shadow?.fault).filter(Boolean);
    row.lagHistogram = runs.map(run => run.shadow?.latency.lagFrameHistogram).filter(Boolean);
    row.audio = runs.map(run => run.audio?.contexts?.join("/") ?? "").filter(Boolean);
    row.workerThreads = runs.map(run => run.trace?.workerThreads?.slice(0, 4)).filter(Boolean);
    row.endStates = runs.map(run => run.snapshot && { paused: run.snapshot.paused, altMeters: run.snapshot.flightState?.altMeters, airspeedKts: run.snapshot.flightState?.airspeedKts });
  }
}
/** Paired (same run number, adjacent in ABBA order) difference a − b of one field. */
const paired = (config, field, readA, readB = readA) => {
  const a = variants.main?.[config], b = variants.shadow?.[config];
  if (!a || !b) return null;
  const byRun = new Map(b.map(run => [run.run, run]));
  const deltas = a.filter(run => byRun.has(run.run)).map(run => { try { return readA(run) - readB(byRun.get(run.run)); } catch { return NaN; } });
  return across(deltas);
};

// The shipping gate: ≥1 ms less main-thread work per frame, or ≥10% better p95 total.
for (const [config, row] of Object.entries(summary)) {
  const main = row.main, shadow = row.shadow;
  if (!main) continue;
  const gate = row.gate = {
    upperBound: {
      savingMeanMs: main.upperSavingMean, p95Fraction: main.upperSavingP95Fraction,
      passesMs: main.upperSavingMean.mean >= 1, passesP95: main.upperSavingP95Fraction.mean >= 0.10,
      // Against the whole main thread (trace busy time and CDP task time), not only the profiled sections.
      traceP95Fraction: main.movableP95.mean / main.traceMainP95.mean,
      cdpMeanFraction: main.movable.mean / main.cdpTask.mean,
    },
  };
  if (shadow?.estimateMean) {
    const savingMean = difference(main.totalMean, shadow.estimateMean);
    const savingP95 = difference(main.totalP95, shadow.estimateP95);
    gate.measured = {
      savingMeanMs: savingMean, savingP95Ms: savingP95,
      p95Fraction: savingP95 && { mean: savingP95.mean / main.totalP95.mean, ci95: savingP95.ci95 / main.totalP95.mean },
      cdpSavingMs: difference(main.cdpTask, shadow.cdpEstimate),
      shadowOverheadMs: difference(shadow.totalMean, main.totalMean),
      passesMs: savingMean ? savingMean.mean - savingMean.ci95 >= 1 : false,
      passesP95: savingP95 ? (savingP95.mean - savingP95.ci95) / main.totalP95.mean >= 0.10 : false,
      paired: {
        savingMeanMs: paired(config, "", FIELDS.totalMean, FIELDS.estimateMean),
        savingP95Ms: paired(config, "", FIELDS.totalP95, FIELDS.estimateP95),
        cdpSavingMs: paired(config, "", FIELDS.cdpTask, FIELDS.cdpEstimate),
        // Negative: the shadow adds main-thread work on top of the full app.
        mainMinusShadowTotalMs: paired(config, "", FIELDS.totalMean, FIELDS.totalMean),
        // Whole main thread, including message dispatch and clone time the profiler cannot see.
        mainMinusShadowCdpTaskMs: paired(config, "", FIELDS.cdpTask, FIELDS.cdpTask),
        mainMinusShadowTraceMeanMs: paired(config, "", FIELDS.traceMainMean, FIELDS.traceMainMean),
        mainMinusShadowGcMsPerSecond: paired(config, "", FIELDS.gcMsPerSecond, FIELDS.gcMsPerSecond),
      },
    };
  }
}

const out = path.join(here, "aggregate.json");
await writeFile(out, JSON.stringify({ dirs: dirs.map(dir => path.relative(here, dir)), summary }, null, 2));

const f = (stat, digits = 3) => stat ? `${stat.mean.toFixed(digits)} ±${Number.isFinite(stat.ci95) ? stat.ci95.toFixed(digits) : "–"} [${stat.min.toFixed(digits)}–${stat.max.toFixed(digits)}]` : "–";
const pct = stat => stat ? `${(stat.mean * 100).toFixed(1)}%` + (Number.isFinite(stat.ci95) ? ` ±${(stat.ci95 * 100).toFixed(1)}` : "") : "–";
console.log("\n## Baseline (main), ms per frame, mean ±95% CI [min–max] over runs\n");
console.log("| Config | Runs | Total mean | Total p95 | physics | contact | collision | native step | audio publish | view | instruments | render | CDP task | Trace main p95 | GC ms/s |");
console.log("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |");
for (const [config, row] of Object.entries(summary)) {
  const m = row.main; if (!m) continue;
  console.log(`| ${config} | ${m.runs} | ${f(m.totalMean)} | ${f(m.totalP95)} | ${f(m.physics)} | ${f(m.contact)} | ${f(m.collision)} | ${f(m.nativeStep)} | ${f(m.audioPublish)} | ${f(m.view)} | ${f(m.instruments)} | ${f(m.render)} | ${f(m.cdpTask)} | ${f(m.traceMainP95)} | ${f(m.gcMsPerSecond, 2)} |`);
}
console.log("\n## Upper bound and gate\n");
console.log("| Config | Movable mean | Upper-bound saving mean | Upper-bound p95 saving | vs trace p95 | vs CDP task | Shadow main cost | Measured saving mean | Measured p95 saving | CDP-basis saving |");
console.log("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |");
for (const [config, row] of Object.entries(summary)) {
  const m = row.main, s = row.shadow, g = row.gate; if (!m) continue;
  const d = stat => stat ? `${stat.mean.toFixed(3)} ±${stat.ci95.toFixed(3)}` : "–";
  console.log(`| ${config} | ${f(m.movable)} | ${f(m.upperSavingMean)} | ${pct(m.upperSavingP95Fraction)} | ${(g.upperBound.traceP95Fraction * 100).toFixed(1)}% | ${(g.upperBound.cdpMeanFraction * 100).toFixed(1)}% | ${s ? f(s.dynamics) : "–"} | ${d(g?.measured?.savingMeanMs)} | ${g?.measured?.p95Fraction ? pct(g.measured.p95Fraction) : "–"} | ${d(g?.measured?.cdpSavingMs)} |`);
}
if (Object.values(summary).some(row => row.gate?.measured)) {
  console.log("\n## Paired worker-path estimate (main − worker path; positive is a saving), mean ±95% CI over run pairs\n");
  console.log("| Config | Pairs | Profiler mean | Profiler p95 | p95 fraction | CDP task | Shadow added: profiler / CDP / trace mean | GC ms/s added | Gate |");
  console.log("| --- | --- | --- | --- | --- | --- | --- | --- | --- |");
  const d = stat => stat ? `${stat.mean.toFixed(3)} ±${Number.isFinite(stat.ci95) ? stat.ci95.toFixed(3) : "–"}` : "–";
  const neg = stat => stat ? `${(-stat.mean).toFixed(3)}` : "–";
  for (const [config, row] of Object.entries(summary)) {
    const p = row.gate?.measured?.paired; if (!p) continue;
    const fraction = p.savingP95Ms && row.main.totalP95 ? `${(p.savingP95Ms.mean / row.main.totalP95.mean * 100).toFixed(1)}%` : "–";
    const passes = p.savingMeanMs && p.savingP95Ms && ((p.savingMeanMs.mean - p.savingMeanMs.ci95) >= 1 || (p.savingP95Ms.mean - p.savingP95Ms.ci95) / row.main.totalP95.mean >= 0.10);
    console.log(`| ${config} | ${p.savingMeanMs?.n ?? 0} | ${d(p.savingMeanMs)} | ${d(p.savingP95Ms)} | ${fraction} | ${d(p.cdpSavingMs)} | ${neg(p.mainMinusShadowTotalMs)} / ${neg(p.mainMinusShadowCdpTaskMs)} / ${neg(p.mainMinusShadowTraceMeanMs)} | ${neg(p.mainMinusShadowGcMsPerSecond)} | ${passes ? "frame-time clause passes" : "fails"} |`);
  }
}
if (Object.values(summary).some(row => row.shadow)) {
  console.log("\n## Shadow worker\n");
  console.log("| Config | Worker steps/s | Worker busy ms/s | Round trip mean / max ms | Dropped ms/s | Queries/frame | Lag frames | Input→observed p50 / p95 ms | Parity |");
  console.log("| --- | --- | --- | --- | --- | --- | --- | --- | --- |");
  for (const [config, row] of Object.entries(summary)) {
    const s = row.shadow; if (!s) continue;
    const parity = s.parity.map(p => p.error ? `error` : `${p.steps} steps, ${p.stateMismatches} state / ${p.audioMismatches} audio mismatches`).join("; ");
    console.log(`| ${config} | ${f(s.workerStepsPerSecond, 1)} | ${f(s.workerBusyMsPerSecond, 1)} | ${s.roundTripMeanMs?.mean.toFixed(3)} / ${s.roundTripMaxMs?.max.toFixed(2)} | ${f(s.droppedMsPerSecond, 1)} | ${s.queriesPerFrame?.mean.toFixed(2)} | ${s.lagFramesMean?.mean.toFixed(2)} | ${s.inputToObservedP50?.mean.toFixed(2)} / ${s.inputToObservedP95?.mean.toFixed(2)} | ${parity || "–"} |`);
  }
}
console.log("\nWrote", path.relative(process.cwd(), out));
