import {readFile,writeFile} from 'node:fs/promises';
import {stripTypeScriptTypes} from 'node:module';
import {pathToFileURL} from 'node:url';
import {NullEngine,Scene,MeshBuilder,PBRMaterial,PBRMaterialDefines,DepthRenderer} from '../../node_modules/@babylonjs/core/index.js';
const root='/Users/felg/gh/0sfs';
const out=`${root}/fly/build/perf-20261021`;
const babylon=pathToFileURL(`${root}/fly/node_modules/@babylonjs/core/index.js`).href;
const result=[];
for(const [label,path] of [['before',`${out}/baseline-engineExhaustDepth.ts`],['after',`${root}/exhaust/src/engineExhaustDepth.ts`]]){
 let source=stripTypeScriptTypes(await readFile(path,'utf8'));
 source=source.replaceAll('"@babylonjs/core"',JSON.stringify(babylon))
 .replaceAll('"@babylonjs/core/Rendering/depthRendererSceneComponent"',JSON.stringify(pathToFileURL(`${root}/fly/node_modules/@babylonjs/core/Rendering/depthRendererSceneComponent.js`).href));
 const module=`${out}/render-list-invalidation-${label}.mjs`;await writeFile(module,source);
 const {createEngineExhaustDepth}=await import(pathToFileURL(module).href);
 const engine=new NullEngine();const scene=new Scene(engine);
 const plume=MeshBuilder.CreateBox('plume',{},scene);
 const hardware=MeshBuilder.CreateBox('hardware',{},scene);hardware.material=new PBRMaterial('metal',scene);
 const depth=createEngineExhaustDepth(scene,plume,()=>{});
 const originalReady=DepthRenderer.prototype.isReady;DepthRenderer.prototype.isReady=()=>true;
 depth.setActive(true,1);
 const defines=new PBRMaterialDefines();hardware.subMeshes[0].materialDefines=defines;
 let dirtyFrames=0;
 for(let i=0;i<120;i++){defines.markAsProcessed();scene.onBeforeRenderObservable.notifyObservers(scene);if(defines._areLightsDirty)dirtyFrames++;}
 result.push({label,frames:120,dirtyFrames,candidates:depth.texture.renderList.map(m=>m.name)});
 depth.dispose();DepthRenderer.prototype.isReady=originalReady;scene.dispose();engine.dispose();
}
await writeFile(`${out}/render-list-invalidation-report.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
