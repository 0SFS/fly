import { performance } from 'node:perf_hooks';
import { readFileSync, writeFileSync } from 'node:fs';
import { f135ExhaustOpticalData as profile } from '../../../F135/src/generated/f135ExhaustOpticalData.ts';
import * as before from './gas-optics-before/engineGasOptics.ts';
import * as after from '../../../exhaust/src/engineGasOptics.ts';

const domain = { axialDistanceRangeMeters: [-2, 6], sections: [
  { distanceMeters: -2, radiusMeters: 0.8, innerRadiusMeters: 0.3, areaFactor: 0.9 },
  { distanceMeters: 0, radiusMeters: 0.6 }, { distanceMeters: 6, radiusMeters: 1.02 }] };
const state = { temperatureKelvin: 1800, ambientTemperatureKelvin: 288.15, augmentation: true,
  fuelFlowKgPerSecond: 3, afterburnerBurnedFuelFlowKgPerSecond: 1, radiusMeters: 0.6, lengthMeters: 6,
  upstreamGasTemperatureKelvin: 1000, ambientPressurePascal: 101325, flowDomain: domain };
const legacy = JSON.parse(readFileSync(new URL('../../../F135/validation/evidence/aircraft/f35b/plume-spatial-2026-10-06/spatial-optics/source-0-f135-exhaust-lut.manifest.json.txt', import.meta.url), 'utf8')).profile;

let nodesCompared = 0;
function equal(a, b, path = '') {
  if (ArrayBuffer.isView(a) || Array.isArray(a)) {
    if (a.length !== b.length) throw Error(`Length mismatch ${path}`);
    for (let i = 0; i < a.length; i++) equal(a[i], b[i], `${path}[${i}]`);
  } else if (a !== null && typeof a === 'object') {
    if (Object.keys(a).join('/') !== Object.keys(b).join('/')) throw Error(`Keys mismatch ${path}`);
    for (const key of Object.keys(a)) equal(a[key], b[key], `${path}.${key}`);
  } else {
    nodesCompared++;
    if (!Object.is(a, b)) throw Error(`Value mismatch ${path}: ${a} != ${b}`);
  }
}
const correctnessStart = performance.now();
for (const p of [profile, legacy]) {
  for (const temperatureKelvin of [150, 200, 300, 1000, 1800, 2500, 3200]) {
    for (const parcel of [false, true]) for (const shaped of [false, true]) for (const samples of [[8, 8], [32, 16], [64, 32]]) {
      const input = { ...state, temperatureKelvin, upstreamGasTemperatureKelvin: parcel ? 1000 : undefined,
        flowDomain: shaped ? domain : undefined, axialSamples: samples[0], radialSamples: samples[1] };
      equal(before.evaluateEngineGasOptics(p, input), after.evaluateEngineGasOptics(p, input));
    }
  }
}
const correctness = { cases: 168, scalarValues: nodesCompared, ms: performance.now() - correctnessStart, exact: true };
const iterations = Number(process.env.GAS_BENCH_ITERATIONS ?? 160);
let sink = 0;
const scenarios = [
  ['changing-temperature-dry', { ...state, augmentation: false, afterburnerBurnedFuelFlowKgPerSecond: 0 }],
  ['changing-temperature-afterburner', state],
  ['changing-temperature-and-geometry', state],
];
const results = [];
for (const [name, base] of scenarios) {
  const measure = (module, count) => {
    const start = performance.now();
    for (let i = 0; i < count; i++) {
      const geometry = name.endsWith('geometry') ? { flowDomain: { ...domain, sections: domain.sections.map((s, j) =>
        ({ ...s, radiusMeters: s.radiusMeters + 0.00001 * i * (j + 1) })) } } : {};
      const result = module.evaluateEngineGasOptics(profile, { ...base, ...geometry, temperatureKelvin: 1600 + i % 600,
        fuelFlowKgPerSecond: 3 + (i % 37) / 100 });
      sink += result.totalSourcePowerUpperBoundW;
    }
    return (performance.now() - start) / count;
  };
  measure(before, 60); measure(after, 60);
  const old = [], current = [];
  for (let round = 0; round < 5; round++) {
    if (round % 2) { current.push(measure(after, iterations)); old.push(measure(before, iterations)); }
    else { old.push(measure(before, iterations)); current.push(measure(after, iterations)); }
  }
  const median = values => values.toSorted((a, b) => a - b)[2];
  results.push({ name, beforeMs: median(old), afterMs: median(current), speedup: median(old) / median(current), beforeTrials: old, afterTrials: current });
}
const report = { correctness, iterations, results, sink, node: process.version };
writeFileSync(new URL('./gas-optics-report.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
